package com.controller;

import com.core.SendEmailSMTP;
import com.persistence.*;
import com.security.AdminToken;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static org.mockito.Mockito.*;

public class PacienteControllerTest {

    @InjectMocks
    private PacienteController pacienteController;

    @Mock
    MedicoRepository medicoRepository;

    @Mock
    CitaRepository citaRepository;

    @Mock
    com.persistence.PacienteRepository pacienteRepository;

    @Mock
    MedicamentoRepository medicamentoRepository;

    @Mock
    AdminToken adminToken;

    @Mock
    LogsRepository logsRepository;

    @Mock
    SendEmailSMTP sendEmailSMTP;


    private UUID token = UUID.randomUUID();

    private Medico medico = null;
    private Cita cita = null;
    private Medicamento medicamento = null;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);

        // Whitebox.setInternalState(pacienteController, "logicCipher", logicCipher);

        cita = new Cita();
        cita.setId(1);

        medico = new Medico();
        medico.setNombre("userName");
        medico.setApellidos("apell");
        medico.setMail("mail");
        medico.setLogin("login");
        medico.setId(1);

        medicamento = new Medicamento();
        medicamento.setNombre("Paracetamol 1000mg");
        medicamento.setDosis("3 veces al día durante 7 días");

        when(adminToken.getLogin(token)).thenReturn("loginUser");
    }
}