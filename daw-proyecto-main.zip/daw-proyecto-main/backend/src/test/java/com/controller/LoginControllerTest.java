package com.controller;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class LoginControllerTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void loggin() {
    }

    @Test
    public void changePassw() {
    }

    @Test
    public void setPassw() {
    }

    @Test
    public void logout() {
    }
}