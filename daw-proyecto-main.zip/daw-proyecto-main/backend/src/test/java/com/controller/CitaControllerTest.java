package com.controller;

import com.core.SendEmailSMTP;
import com.persistence.*;
import com.security.AdminToken;
import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.reflect.Whitebox;

import java.util.UUID;


public class CitaControllerTest {

    @InjectMocks
    private CitaController citaController;

    @Mock
    MedicamentoRepository medicamentoRepository;

    @Mock
    AdminToken adminToken;

    @Mock
    LogsRepository logsRepository;

    @Mock
    PacienteRepository pacienteRepository;

    @Mock
    CitaRepository citaRepository;

    @Mock
    SendEmailSMTP sendEmailSMTP;

    private UUID token = UUID.randomUUID();
    private Cita hosp = null;
    private String codigo = "codBote";

    @Before
    public void initMocks(){
        MockitoAnnotations.initMocks(this);
        // Whitebox.setInternalState(citaController, "logicCipher", logicCipher);

        hosp = new Cita();
        hosp.setId(1);
    }

}