-- INSERT INTO medico (id, nombre, apellidos, mail, login, password, fecha_creacion) VALUES (1, 'nombre', 'apellidos', 'test@mail.com', 'medico', '12345678', CURDATE());
INSERT INTO proyecto.medico (id, apellidos, fecha_creacion, login, mail, nombre, password) VALUES (1, 'Gómez', '2022-10-07 00:00:00', 'lgomez', 'lucia.gomez@mail.com', 'Lucía', 'MTIzNDU2Nzg=');
INSERT INTO proyecto.medico (id, apellidos, fecha_creacion, login, mail, nombre, password) VALUES (2, 'García', '2022-10-07 00:00:00', 'cgarcia', 'carlos.garcia@mail.com', 'Carlos', 'MTIzNDU2Nzg=');
INSERT INTO proyecto.medico (id, apellidos, fecha_creacion, login, mail, nombre, password) VALUES (3, 'Sánchez', '2022-10-07 00:00:00', 'mgonzalez', 'mario.sanchez@mail.com', 'Marrio', 'MTIzNDU2Nzg=');
--

INSERT INTO proyecto.paciente (id, apellidos, documento, fecha_creacion, fecha_nacimiento, nombre, password, telefono, genero, historial) VALUES (1, 'Gil Montero', '12345678A', '2022-10-10 15:34:51', '1979-09-24 00:00:00', 'Jose Antonio', 'YXNk', 676052042, 'M', 'Vegetaciones
Admigdalas
Estrabismo
Hernia de hiato ');
INSERT INTO proyecto.paciente (id, apellidos, documento, fecha_creacion, fecha_nacimiento, nombre, password, telefono, genero, historial) VALUES (2, 'García', '12345678B', '2022-10-10 15:37:03', '1980-01-01 00:00:00', 'Gumersinda', 'YXNk', 666555444, 'F', '-');
INSERT INTO proyecto.paciente (id, apellidos, documento, fecha_creacion, fecha_nacimiento, nombre, password, telefono, genero, historial) VALUES (3, 'Simón', '12345678C', '2022-12-13 23:25:10', '1993-03-10 00:29:53', 'Samuel', 'YXNk', 111222333, 'M', '-');
INSERT INTO proyecto.paciente (id, apellidos, documento, fecha_creacion, fecha_nacimiento, nombre, password, telefono, genero, historial) VALUES (4, 'Martín', '12345678D', '2022-11-21 17:40:08', '1970-01-01 00:00:00', 'Manuel', 'YXNk', 6677, null, null);
INSERT INTO proyecto.paciente (id, apellidos, documento, fecha_creacion, fecha_nacimiento, nombre, password, telefono, genero, historial) VALUES (5, 'Antúnez', '87654321A', '2022-12-08 23:38:56', '2008-06-17 00:00:00', 'Agapito', 'YXNk', 123456789, 'M', null);

--
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (1, '2022-12-30 12:00:00', 1, 1, 1);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (2, '2022-12-29 16:00:00', 1, 2, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (3, '2022-12-30 11:30:00', 1, 3, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (4, '2023-01-02 09:45:00', 1, 4, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (5, '2023-01-03 08:15:00', 3, 5, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (6, '2023-01-04 15:15:00', 2, 1, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (7, '2023-01-05 15:15:00', 3, 2, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (8, '2023-01-04 10:30:00', 2, 3, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (9, '2023-01-03 15:30:00', 2, 4, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (10, '2023-01-23 15:15:00', 1, 1, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (11, '2023-01-24 10:30:00', 1, 2, 0);
INSERT INTO proyecto.cita (id, fecha, medico_id, paciente_id, status) VALUES (12, '2023-01-25 17:30:00', 1, 3, 0);

--
INSERT INTO proyecto.noticia (id, descripcion, enlace, fecha, imagen, titulo) VALUES (5, '', 'https://www.lavanguardia.com/local/catalunya/20230101/8664834/primer-bebe-2023-catalunya-nacido-hospital-palamos.html', '2023-01-01 13:22:00', 'https://www.lavanguardia.com/files/image_948_465/files/fp/uploads/2023/01/01/63b171798eab7.r_d.390-1055-5486.png', 'Iratxe y Zakaria, los primeros bebés del 2023 nacidos en Madrid y Palamós');
INSERT INTO proyecto.noticia (id, descripcion, enlace, fecha, imagen, titulo) VALUES (4, '', 'https://espanol.cdc.gov/coronavirus/2019-ncov/your-health/treatments-for-severe-illness.html', '2022-12-30 10:41:00', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmXa6K4ELH7hgOxF_aaFzt-UN7FAvoWdacrA&usqp=CAU', 'Los médicos descubren cura contra el covid instantánea');
INSERT INTO proyecto.noticia (id, descripcion, enlace, fecha, imagen, titulo) VALUES (3, '', 'https://www.infobae.com/america/ciencia-america/2022/12/25/cuando-el-medicamento-esta-en-el-cuerpo-como-es-el-autotrasplante-de-celulas-madre-para-la-esclerosis-multiple/', '2022-12-24 11:57:00', 'https://www.infobae.com/new-resizer/Oi3lPohiSZI-slllqd9p8tRsIAQ=/992x558/filters:format(webp):quality(85)/cloudfront-us-east-1.images.arcpublishing.com/infobae/DR7LT4UGGFHENC2BBE2XDWHHTI.jpg', 'Información sobre las células madre para la esclerosis');
INSERT INTO proyecto.noticia (id, descripcion, enlace, fecha, imagen, titulo) VALUES (2, '', 'https://elpais.com/espana/madrid/2022-12-22/el-75-de-los-directores-de-los-centros-de-salud-presiona-al-gobierno-de-ayuso-para-que-negocie-de-manera-seria-con-los-medicos.html', '2022-12-19 17:46:00', 'https://imagenes.elpais.com/resizer/0wq4y0xb1pbV2HXV-uIpM9pBqj4=/1200x675/cloudfront-eu-central-1.images.arcpublishing.com/prisa/EFVM6LRAJJBM5NPABY2XKD7TC4.jpg', 'Los médicos de Madrid suspenden temporalmente la huelga');
INSERT INTO proyecto.noticia (id, descripcion, enlace, fecha, imagen, titulo) VALUES (1, '', 'https://www.cope.es/actualidad/sociedad/noticias/espana-referencia-union-europea-medicina-precision-medicina-personalizada-20221229_2471859', '2022-12-13 09:58:00', 'https://cope-cdnmed.agilecontent.com/resources/png/7/9/1672277078597.png', 'Predecir el riesgo de sufrir una enfermedad: España es referencia en medicina de precisión y personalizada');

--
--
--
