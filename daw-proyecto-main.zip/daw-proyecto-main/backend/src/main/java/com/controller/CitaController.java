package com.controller;

import com.controller.dto.CitaRequest;
import com.persistence.*;
import com.security.AdminToken;
import com.utils.CitaStatusEnum;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;


@RestController
@CrossOrigin()
@RequestMapping("/citas")
public class CitaController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CitaController.class);

    @Autowired
    AdminToken adminToken;
    @Autowired
    CitaRepository citaRepository;
    @Autowired
    MedicoRepository medicoRepository;
    @Autowired
    PacienteRepository pacienteRepository;


    @RequestMapping()
    public ResponseEntity<List<Cita>> getCitas(@RequestHeader(value = "token") UUID token,
                                               @RequestParam(value="status") String status) throws Exception {

        Medico medico = adminToken.isValidTokenMedico(token);

        LOGGER.info("{}: findAllCitas", adminToken.getLogin(token));

        if (medico != null) {
            if (Strings.isNotBlank(status) && Strings.isNotEmpty(status)) {
                CitaStatusEnum citaStatus = CitaStatusEnum.getByName(status);
                if (status != null) {
                    return new ResponseEntity<>(citaRepository.findByMedicoAndStatusOrderByFechaDesc(medico, citaStatus), HttpStatus.OK);
                }
            }
            return new ResponseEntity<>(citaRepository.findByMedicoOrderByFechaDesc(medico), HttpStatus.OK);
        }

        LOGGER.error("{} no tiene permisos para buscar citas", adminToken.getLogin(token));
        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }

    @RequestMapping("/paciente")
    public ResponseEntity<List<Cita>> getCitasPaciente(@RequestHeader(value = "token") UUID token) throws Exception {

        Paciente paciente = adminToken.isValidTokenPaciente(token);

        LOGGER.info("{}: findAllCitasPaciente", adminToken.getLogin(token));

        if (paciente != null) {
            List<Cita> citas = citaRepository.findByPacienteOrderByFechaDesc(paciente);
            return new ResponseEntity<>(citas, HttpStatus.OK);
        }

        LOGGER.error("{} no tiene permisos para buscar citas", adminToken.getLogin(token));
        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }

    @RequestMapping("/{idCita}")
    public ResponseEntity<Cita> getCita(@RequestHeader(value = "token") UUID token,
                                        @PathVariable(value = "idCita") Integer idCita) {

        Medico medico = adminToken.isValidTokenMedico(token);

        LOGGER.info("{}: getCita", adminToken.getLogin(token));

        if (medico != null) {
            Optional<Cita> cita = citaRepository.findById(idCita);
            if (cita.isPresent()) {
                return new ResponseEntity<>(cita.get(), HttpStatus.OK);
            }
            LOGGER.error("La cita con ID {} no existe", idCita);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        LOGGER.error("{} no tiene permisos para buscar citas", adminToken.getLogin(token));
        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }

    @PostMapping()
    public ResponseEntity<Cita> crearCita(@RequestHeader(value = "token") UUID token,
                                          @RequestBody CitaRequest request) throws Exception {

        Integer idMedico = request.getIdMedico();
        checkMandatoryParams(idMedico, request.getFecha());

        Paciente paciente = adminToken.isValidTokenPaciente(token);

        if (paciente == null) {
            LOGGER.error("Invalid access token: {}", token);
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        Optional<Medico> optionalMedico = medicoRepository.findById(idMedico);
        if (!optionalMedico.isPresent()) {
            LOGGER.error("No existe ningún médico con el ID {} ", idMedico);
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        LOGGER.info("Crear cita: {}, {}, {}", paciente.getDocumento(), idMedico, request.getFecha());

        // logsRepository.save(Utils.buildLine(user.getLogin(), String.format("Add bote '%s' tipo: '%s' ", codigo, cipher)));

        Medico medico = optionalMedico.get();

        Cita cita = new Cita(request.getFecha(), null, medico, paciente);
        cita = citaRepository.save(cita);

        return new ResponseEntity<>(cita, HttpStatus.OK);
    }

    @PutMapping("/{idCita}")
    public ResponseEntity<Cita> saveCita(@RequestHeader(value = "token") UUID token,
                                          @PathVariable(value = "idCita") Integer idCita,
                                          @RequestBody Cita request) throws Exception {

        Medico medico = adminToken.isValidTokenMedico(token);

        if (medico == null) {
            LOGGER.error("Invalid access token: {}", token);
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        Optional<Cita> cita = citaRepository.findById(idCita);
        if (!cita.isPresent()) {
            LOGGER.error("ID de cita no válido: {}", idCita);
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        pacienteRepository.save(request.getPaciente());
        request = citaRepository.save(request);

        return new ResponseEntity<>(request, HttpStatus.OK);
    }
    @PutMapping("/{idCita}/reagendar")
    public ResponseEntity<CitaRequest> updateCita(@RequestHeader(value = "token") UUID token,
                                          @PathVariable(value = "idCita") Integer idCita,
                                          @RequestBody CitaRequest request) throws Exception {

        Integer idMedico = request.getIdMedico();
        checkMandatoryParams(idMedico, request.getFecha());

        Paciente paciente = adminToken.isValidTokenPaciente(token);

        if (paciente == null) {
            LOGGER.error("Invalid access token: {}", token);
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        Optional<Medico> optionalMedico = medicoRepository.findById(idMedico);
        if (!optionalMedico.isPresent()) {
            LOGGER.error("No existe ningún médico con el ID {} ", idMedico);
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        Medico medico = optionalMedico.get();

        Optional<Cita> optionalCita = citaRepository.findById(idCita);
        if (!optionalCita.isPresent()) {
            LOGGER.error("ID de cita no válido: {}", idCita);
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
        Cita cita = optionalCita.get();
        cita.setMedico(medico);
        cita.setFecha(request.getFecha());
        citaRepository.save(cita);

        LOGGER.info("Actualizar cita: {}, {}, {}, {}", idCita, paciente.getDocumento(), idMedico, request.getFecha());

        return new ResponseEntity<>(request, HttpStatus.OK);
    }

}