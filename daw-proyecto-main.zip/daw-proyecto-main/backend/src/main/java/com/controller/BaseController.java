package com.controller;

import org.springframework.util.StringUtils;

/**
 * @author joseg
 * Date 14/12/2022
 */

public class BaseController {

    public void checkMandatoryParams(Object... params) throws Exception {

        for (Object param : params) {
            if (param == null || StringUtils.isEmpty(param.toString())) {
                throw new Exception("Wrong payload");
            }
        }
    }

}
