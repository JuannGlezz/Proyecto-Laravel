package com.controller;

import com.controller.dto.PacienteResponse;
import com.persistence.*;
import com.security.AdminToken;
import com.utils.MSG;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@CrossOrigin()
@RestController
@RequestMapping("/pacientes")
public class PacienteController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(PacienteController.class);

    @Autowired
    PacienteRepository pacienteRepository;

    @Autowired
    AdminToken adminToken;

    @Autowired
    LogsRepository logsRepository;


    @GetMapping()
    public List<PacienteResponse> getAll(@RequestHeader(value = "token") UUID token) throws Exception {

        Medico medico = adminToken.isValidTokenMedico(token);
        LOGGER.info("{}: findAllPacientes", adminToken.getLogin(token));

        if (medico != null) {
            Iterable<Paciente> pacientes = pacienteRepository.findAll();

            List<PacienteResponse> listaPacientes = new ArrayList<>();
            pacientes.forEach(paciente -> {
                PacienteResponse pacienteResponse = new PacienteResponse(paciente);
                listaPacientes.add(pacienteResponse);
            });
            return listaPacientes;
        }

        LOGGER.error("{} no tiene permisos para buscar pacientes", adminToken.getLogin(token));
        throw new Exception(MSG.NOT_PERM.getMsg());
    }

    @GetMapping("/get")
    public ResponseEntity<PacienteResponse> getPaciente(@RequestHeader(value = "token") UUID token) throws Exception {

        Paciente paciente = adminToken.isValidTokenPaciente(token);
        LOGGER.info("{}: getPaciente", adminToken.getLogin(token));

        if (paciente != null) {
            return new ResponseEntity(new PacienteResponse(paciente), HttpStatus.OK);
        }
        LOGGER.error("{} no tiene permisos para buscar pacientes", adminToken.getLogin(token));
        throw new Exception(MSG.NOT_PERM.getMsg());
    }

    @GetMapping("/search")
    public List<PacienteResponse> searchPacientes(@RequestHeader(value = "token") UUID token, @RequestParam(value = "q") String searchText) throws Exception {

        Medico medico = adminToken.isValidTokenMedico(token);

        LOGGER.info("{}: findAllPacientes", adminToken.getLogin(token));

        if (medico != null) {
            Iterable<Paciente> pacientes = pacienteRepository.findByNombreOrApellidosOrDocumento(searchText, searchText, searchText);

            List<PacienteResponse> listaPacientes = new ArrayList<>();
            pacientes.forEach(paciente -> {
                PacienteResponse pacienteResponse = new PacienteResponse(paciente);
                listaPacientes.add(pacienteResponse);
            });
            return listaPacientes;
        }

        LOGGER.error("{} no tiene permisos para buscar Pacientes", adminToken.getLogin(token));
        throw new Exception(MSG.NOT_PERM.getMsg());
    }

    // @Transactional
    @PostMapping()
    public PacienteResponse savePaciente(@RequestBody PacienteResponse paciente) throws Exception {

        checkMandatoryParams(paciente.getDocumento(), paciente.getPassword(), paciente.getNombre(),
                paciente.getApellidos(), paciente.getFechaNacimiento().toString());

        LOGGER.info("Save Paciente {},{},{},{}",
                paciente.getDocumento(), paciente.getNombre(), paciente.getApellidos(), paciente.getTelefono());

        Paciente existePaciente = pacienteRepository.findByDocumento(paciente.getDocumento());
        if (existePaciente != null) {
            LOGGER.error("Ya existe un paciente con el documento {}", paciente.getDocumento());
            throw new Exception(MSG.PATIENT_EXIST.getMsg());
        }

        String password = Base64.getEncoder().encodeToString(paciente.getPassword().getBytes());

        Paciente newPaciente = new Paciente(paciente.getNombre(), paciente.getApellidos(), paciente.getTelefono(),
                paciente.getGenero(), paciente.getFechaNacimiento(), paciente.getDocumento(), password);

        newPaciente = pacienteRepository.save(newPaciente);
        paciente.setId(newPaciente.getId());
        paciente.setPassword(null);

        return paciente;
    }

    @PutMapping()
    public ResponseEntity<PacienteResponse> updatePaciente(@RequestHeader(value = "token") UUID token, @RequestBody PacienteResponse paciente) throws Exception {

        Paciente loggedUser = adminToken.isValidTokenPaciente(token);
        if (loggedUser != null) {

            checkMandatoryParams(paciente.getId().toString(), paciente.getNombre(), paciente.getApellidos(),
                    paciente.getTelefono().toString(), paciente.getGenero());

            LOGGER.info("Update Paciente {},{},{},{}",
                    paciente.getId(), paciente.getNombre(), paciente.getApellidos(), paciente.getTelefono());

            Optional<Paciente> optionalPaciente = pacienteRepository.findById(paciente.getId());
            if (!optionalPaciente.isPresent()) {
                LOGGER.error("No existe el paciente con el ID {}", paciente.getId());
                throw new Exception(MSG.PATIENT_NOT_EXIST.getMsg());
            }
            Paciente oldPaciente = optionalPaciente.get();
            oldPaciente.setNombre(paciente.getNombre());
            oldPaciente.setApellidos(paciente.getApellidos());
            oldPaciente.setTelefono(paciente.getTelefono());
            oldPaciente.setGenero(paciente.getGenero());

            pacienteRepository.save(oldPaciente);

            return new ResponseEntity<>(paciente, HttpStatus.OK);
        }

        LOGGER.error("{} no tiene permisos para editar los datos del Paciente", adminToken.getLogin(token));
        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }

}