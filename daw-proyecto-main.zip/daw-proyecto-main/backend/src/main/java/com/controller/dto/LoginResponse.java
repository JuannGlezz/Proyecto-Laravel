package com.controller.dto;

import java.util.UUID;

public class LoginResponse {

    private UUID token;
    private String login;
    private String nombre;

    public LoginResponse(UUID token, String login, String nombre) {
        this.token = token;
        this.login = login;
        this.nombre = nombre;
    }


    public UUID getToken() {
        return token;
    }

    public void setToken(UUID token) {
        this.token = token;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
