package com.controller;

import com.core.SendEmailSMTP;
import com.persistence.Noticia;
import com.persistence.NoticiaRepository;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Map;

/**
 * @author joseg
 * Date 02/01/2023
 */

@CrossOrigin()
@RestController
@RequestMapping()
public class MainController extends BaseController {

    @Autowired
    private NoticiaRepository noticiaRepository;

    @Autowired
    private SendEmailSMTP sendEmailSMTP;

    @GetMapping("/noticias")
    public List<Noticia> getNews() {
        return noticiaRepository.findAllByOrderByFechaDesc();
    }

    @PostMapping("/contacto")
    public ResponseEntity contactar(@RequestBody Map<String, String> params) {

        try {
            checkMandatoryParams("nombre", "email", "mensaje", "cc");

            System.out.println(params);

            Boolean cc =  Boolean.parseBoolean(params.get("cc"));

            sendEmailSMTP.sendMail(params.get("email"), params.get("mensaje"), "Contacto - " + params.get("nombre"), cc);

            return new ResponseEntity(HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(value = "/mapa", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public @ResponseBody byte[] getImage() throws IOException {

        URL url = new URL("https://maps.googleapis.com/maps/api/staticmap?center=40.5250608,-3.6541992&zoom=16&size=400x400&markers=40.5250608,-3.65419928&style=feature:poi|element:labels|visibility:off&key=AIzaSyAQWinEfYbtZ6X54Q8xBILVP9Gz7j1vXXA");
        URLConnection conn = url.openConnection();
        InputStream in = conn.getInputStream();

        return IOUtils.toByteArray(in);
    }

}
