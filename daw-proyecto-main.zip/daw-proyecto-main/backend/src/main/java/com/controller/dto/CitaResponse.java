package com.controller.dto;

import com.persistence.*;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class CitaResponse {

    private final String FORMATO_FECHA = "yyyy-MM-dd";
    private final String FORMATO_HORA = "HH:mm";
    private final DateTimeFormatter fechaFormatter = DateTimeFormatter.ofPattern(FORMATO_FECHA);
    private final DateTimeFormatter horaFormatter = DateTimeFormatter.ofPattern(FORMATO_HORA);

    private Integer id;
    private String fecha;
    private String hora;
    private Medico medico;
    private Paciente paciente;
    private List<Medicamento> medicamentos;


    public CitaResponse(Cita cita) {
        this.id = cita.getId();
        this.fecha = fechaFormatter.format(cita.getFecha().toLocalDateTime());
        this.hora = horaFormatter.format(cita.getFecha().toLocalDateTime());
        this.medico = cita.getMedico();
        this.paciente = cita.getPaciente();
        this.medicamentos = cita.getMedicamentos();
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public List<Medicamento> getMedicamentos() {
        return medicamentos;
    }

    public void setMedicamentos(List<Medicamento> medicamentos) {
        this.medicamentos = medicamentos;
    }
}
