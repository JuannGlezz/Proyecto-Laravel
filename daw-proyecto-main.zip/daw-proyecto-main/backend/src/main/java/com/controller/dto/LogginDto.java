package com.controller.dto;

import java.util.ArrayList;
import java.util.Collection;

public class LogginDto {

    private int numRegister;

    private Collection<LineDto> lines;

    private final int MAX_LINES = 200;

    public LogginDto() {
        lines = new ArrayList<>();
    }

    public int getNumRegister() {
        return numRegister;
    }

    public void setNumRegister(int numRegister) {
        this.numRegister = numRegister;
    }

    public Collection<LineDto> getLines() {
        return lines;
    }

    public void setLines(Collection<LineDto> lines) {
        this.lines = lines;
    }

    public boolean addLine(LineDto line) {
        if (lines.size() < MAX_LINES) {
            lines.add(line);
            return true;
        }
        return false;
    }
}
