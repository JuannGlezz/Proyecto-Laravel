package com.controller;

import com.controller.dto.MedicoResponse;
import com.core.SendEmailSMTP;
import com.persistence.*;
import com.security.AdminToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;


@CrossOrigin()
@RestController
@RequestMapping("/medicos")
public class MedicoController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MedicoController.class);

    @Autowired
    MedicoRepository medicoRepository;

    @Autowired
    AdminToken adminToken;

    @Autowired
    LogsRepository logsRepository;

    @Autowired
    SendEmailSMTP sendEmailSMTP;

    private static final AtomicBoolean busy = new AtomicBoolean(false);


    @GetMapping()
    public ResponseEntity<List<MedicoResponse>> getAll(@RequestHeader(value = "token") UUID token) throws Exception {

        Paciente paciente = adminToken.isValidTokenPaciente(token);

        LOGGER.info("{}: findAllMedicos", adminToken.getLogin(token));

        if (paciente != null) {
            Iterable<Medico> medicos = medicoRepository.findAll();

            List<MedicoResponse> listaMedicos = new ArrayList<>();
            medicos.forEach(medico -> {
                MedicoResponse medicoResponse = new MedicoResponse(medico);
                listaMedicos.add(medicoResponse);
            });
            return new ResponseEntity<>(listaMedicos, HttpStatus.OK);
        }

        LOGGER.error("{} no tiene permisos para buscar médicos", adminToken.getLogin(token));
        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }

}