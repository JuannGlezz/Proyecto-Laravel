package com.controller.dto;

import java.sql.Timestamp;

public class CitaRequest {

    private Integer id;
    private Timestamp fecha;
    private Integer idMedico;


    public CitaRequest(Integer id, Timestamp fecha, Integer idMedico) {
        this.id = id;
        this.fecha = fecha;
        this.idMedico = idMedico;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    public Integer getIdMedico() {
        return idMedico;
    }

    public void setIdMedico(Integer idMedico) {
        this.idMedico = idMedico;
    }

}
