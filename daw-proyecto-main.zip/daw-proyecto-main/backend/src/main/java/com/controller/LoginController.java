package com.controller;

import com.controller.dto.LoginRequest;
import com.controller.dto.LoginResponse;
import com.persistence.*;
import com.security.AdminToken;
import com.utils.TipoUsuarioEnum;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Base64;
import java.util.UUID;

@CrossOrigin()
@RestController
@RequestMapping()
public class LoginController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    MedicoRepository medicoRepository;

    @Autowired
    PacienteRepository pacienteRepository;

    @Autowired
    LogsRepository logsRepository;

    @Autowired
    AdminToken adminToken;


    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest req) {

        try {
            String username = req.getLogin();

            LOGGER.info("login de medico: {}", username);

            Medico medico = medicoRepository.findByLogin(username);

            String password = Base64.getEncoder().encodeToString(req.getPassword().getBytes());

            if (medico != null && medico.getPassword().equals(password)) {
                UUID key = adminToken.addToken(medico);
                LoginResponse loginResponse = new LoginResponse(key, username, medico.getNombre());
                return new ResponseEntity<>(loginResponse, HttpStatus.OK);
            }
            LOGGER.error("User {} o Password {} no válidos", username, password);
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (Exception ex) {
            LOGGER.error("Login Médico - Error no controlado: {}", req);
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/login/paciente")
    public ResponseEntity<LoginResponse> loginPaciente(@RequestBody LoginRequest req) {

        try {
            String documento = req.getLogin();

            LOGGER.info("login de paciente: {}", documento);

            Paciente paciente = pacienteRepository.findByDocumento(documento);

            if (paciente != null) {
                String password = Base64.getEncoder().encodeToString(req.getPassword().getBytes());
                if (password.equals(paciente.getPassword())) {
                    UUID key = adminToken.addToken(paciente);
                    LoginResponse loginResponse = new LoginResponse(key, documento, paciente.getNombre());
                    return new ResponseEntity<>(loginResponse, HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
                }
            } else {
                LOGGER.error("Paciente con documento {} no encontrado", documento);
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception ex) {
            LOGGER.error("Login Paciente - Error no controlado: {}", req);
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/token")
    public ResponseEntity<Boolean> checkValidToken(@RequestHeader("token") UUID token, @RequestParam("tipo") String tipo) {
        try {
            if (Strings.isNotBlank(tipo) && Strings.isNotEmpty(tipo)) {
                if (tipo.equals(TipoUsuarioEnum.PACIENTE.name())) {
                    Paciente paciente = adminToken.isValidTokenPaciente(token);
                    if (paciente != null) {
                        return new ResponseEntity<>(true, HttpStatus.OK);
                    }
                } else if (tipo.equals(TipoUsuarioEnum.MEDICO.name())) {
                    Medico medico = adminToken.isValidTokenMedico(token);
                    if (medico != null) {
                        return new ResponseEntity<>(true, HttpStatus.OK);
                    }
                }
            }
        } catch (Exception ex) {
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

//    @RequestMapping("/changePassw")
//    public void changePassw(@RequestParam(value = "token") UUID token, String oldPassw, String newPassw) throws Exception {
//    }

    @PostMapping("/logout")
    public boolean logout(@RequestHeader(value = "token") UUID token) {
        LOGGER.info("logout for {}", adminToken.getLogin(token));
        return adminToken.remove(token);
    }

}