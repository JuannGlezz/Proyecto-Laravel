package com.controller.dto;

import com.persistence.Paciente;

import java.sql.Timestamp;

public class PacienteResponse {

    private Integer id;
    private String documento;
    private String password;
    private String nombre;
    private String apellidos;
    private Long telefono;
    private String genero;
    private Timestamp fechaNacimiento;
    private String historial;


    public PacienteResponse(Paciente paciente) {

        this.id = paciente.getId();
        this.documento = paciente.getDocumento();
        this.nombre = paciente.getNombre();
        this.apellidos = paciente.getApellidos();
        this.telefono = paciente.getTelefono();
        this.genero = paciente.getGenero();
        this.fechaNacimiento = paciente.getFechaNacimiento();
        this.historial = paciente.getHistorial();
    }

    public PacienteResponse() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Long getTelefono() {
        return telefono;
    }

    public void setTelefono(Long telefono) {
        this.telefono = telefono;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Timestamp getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Timestamp fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getHistorial() {
        return historial;
    }

    public void setHistorial(String historial) {
        this.historial = historial;
    }
}
