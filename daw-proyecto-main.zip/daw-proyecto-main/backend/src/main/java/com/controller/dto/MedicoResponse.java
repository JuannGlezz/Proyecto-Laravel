package com.controller.dto;

import com.persistence.Medico;

public class MedicoResponse {

    private Integer id;
    private String nombre;
    private String apellidos;


    public MedicoResponse() {
    }

    public MedicoResponse(Medico medico) {

        this.id = medico.getId();
        this.nombre = medico.getNombre();
        this.apellidos = medico.getApellidos();
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

}
