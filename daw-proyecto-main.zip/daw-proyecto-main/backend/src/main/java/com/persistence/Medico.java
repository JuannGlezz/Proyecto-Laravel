package com.persistence;

import com.utils.TipoUsuarioEnum;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * @author joseg
 * Date 06/10/2022
 */

@Entity
@SequenceGenerator(name="seqMedico", initialValue=10, allocationSize=10)
public class Medico extends Usuario {

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqMedico")
    private Integer id;
    private String nombre;
    private String apellidos;
    private String mail;

    private String login;
    private String password;


    private Timestamp fechaCreacion;

    public Medico() {
        super(TipoUsuarioEnum.MEDICO);
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombreCompleto() {
        return String.format("%s $s", this.nombre, this.apellidos);
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Timestamp getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Timestamp fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

}
