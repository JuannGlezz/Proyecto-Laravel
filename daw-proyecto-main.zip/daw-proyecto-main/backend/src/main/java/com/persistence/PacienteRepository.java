package com.persistence;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PacienteRepository extends CrudRepository<Paciente, Integer> {

    Paciente findByDocumento(String documento);

    List<Paciente> findByNombreOrApellidosOrDocumento(String nombre, String apellidos, String documento);

}
