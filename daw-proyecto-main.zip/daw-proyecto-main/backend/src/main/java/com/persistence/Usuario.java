package com.persistence;

import com.utils.TipoUsuarioEnum;

/**
 * @author joseg
 * Date 07/10/2022
 */

public abstract class Usuario {

    protected TipoUsuarioEnum tipo = null;

    public Usuario(TipoUsuarioEnum tipo) {
        this.tipo = tipo;
    }

    public TipoUsuarioEnum getTipo() {
        return tipo;
    }

    public void setTipo(TipoUsuarioEnum tipo) {
        this.tipo = tipo;
    }

    public abstract String getNombre();

    public abstract String getApellidos();
}
