package com.persistence;

import javax.persistence.*;

@Entity
@SequenceGenerator(name="seqMedicamento", initialValue=10, allocationSize=10)
public class Medicamento {

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqMedicamento")
    private Integer id;

    private String nombre;

    private String dosis;

    private String observaciones;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDosis() {
        return dosis;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

}
