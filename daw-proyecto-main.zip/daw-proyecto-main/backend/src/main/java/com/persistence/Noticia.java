package com.persistence;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * @author joseg
 * Date 02/01/2023
 */

@Entity // This tells Hibernate to make a table out of this class
@SequenceGenerator(name="seqNoticia", initialValue=10, allocationSize=10)
public class Noticia {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqNoticia")
    private Integer id;
    private String titulo;
    private String descripcion;
    @Column(length=1024)
    private String enlace;
    @Column(length=1024)
    private String imagen;
    private Timestamp fecha;

    public Noticia() {
    }

    public Noticia(Integer id, String titulo, String descripcion, String enlace, String imagen, Timestamp fecha) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.enlace = enlace;
        this.imagen = imagen;
        this.fecha = fecha;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEnlace() {
        return enlace;
    }

    public void setEnlace(String enlace) {
        this.enlace = enlace;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }
}
