package com.persistence;

import javax.persistence.*;
import java.util.Date;

@Entity
@SequenceGenerator(name="seqLogs", initialValue=10, allocationSize=10)
public class Logs {

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqLogs")
    private Integer id;

    //	@Column(length=200)
    private String descripcion;

    private String accion;

    private Date date;

    private String user;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
