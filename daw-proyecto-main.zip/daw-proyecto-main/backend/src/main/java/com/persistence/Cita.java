package com.persistence;

import com.utils.CitaStatusEnum;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Entity // This tells Hibernate to make a table out of this class
@SequenceGenerator(name="seqCita", initialValue=10, allocationSize=10)
public class Cita {
    @Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqCita")
    private Integer id;
	private Timestamp fecha;
	private String comentarios;
	private CitaStatusEnum status;
	@OneToOne
	private Medico medico;
	@OneToOne
    private Paciente paciente;
	@OneToMany(cascade = CascadeType.ALL)
	private List<Medicamento> medicamentos;


	public Cita() {
		medicamentos = new ArrayList<>();
	}

	public Cita(Timestamp fecha, String comentarios, Medico medico, Paciente paciente) {
		this();
		this.fecha = fecha;
		this.comentarios = comentarios;
		this.medico = medico;
		this.paciente = paciente;
		this.status = CitaStatusEnum.ABIERTA;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Timestamp getFecha() {
		return fecha;
	}

	public void setFecha(Timestamp fecha) {
		this.fecha = fecha;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	public CitaStatusEnum getStatus() {
		return status;
	}

	public void setStatus(CitaStatusEnum status) {
		this.status = status;
	}

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public List<Medicamento> getMedicamentos() {
		return medicamentos;
	}

	public void setMedicamentos(List<Medicamento> medicamentos) {
		this.medicamentos = medicamentos;
	}

}

