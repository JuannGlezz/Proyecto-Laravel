package com.persistence;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface NoticiaRepository extends CrudRepository<Noticia, Integer> {

    @Query
    List<Noticia> findAllByOrderByFechaDesc();

}
