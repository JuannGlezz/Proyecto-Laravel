package com.persistence;

import com.utils.TipoUsuarioEnum;

import javax.persistence.*;
import java.sql.Timestamp;
import java.time.Instant;

@Entity
@SequenceGenerator(name="seqPaciente", initialValue=10, allocationSize=10)
public class Paciente extends Usuario {

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seqPaciente")
    private Integer id;

    private String nombre;
    private String apellidos;
    private Long telefono;
    private String genero;
    private Timestamp fechaNacimiento;
    private String historial;

    private String documento;
    private String password;

    private Timestamp fechaCreacion;


    public Paciente() {
        super(TipoUsuarioEnum.PACIENTE);
    }

    public Paciente(String nombre, String apellidos, Long telefono, String genero, Timestamp fechaNacimiento, String documento, String password) {

        this();

        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.genero = genero;
        this.fechaNacimiento = fechaNacimiento;
        this.documento = documento;
        this.password = password;

        this.fechaCreacion = Timestamp.from(Instant.now());
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Long getTelefono() {
        return telefono;
    }

    public void setTelefono(Long telefono) {
        this.telefono = telefono;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Timestamp getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Timestamp fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getHistorial() {
        return historial;
    }

    public void setHistorial(String historial) {
        this.historial = historial;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Timestamp getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Timestamp fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

}
