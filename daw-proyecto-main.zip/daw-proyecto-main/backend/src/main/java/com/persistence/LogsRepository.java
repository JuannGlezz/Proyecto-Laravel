package com.persistence;

import org.springframework.data.repository.CrudRepository;

import java.util.Collection;
import java.util.Date;

public interface LogsRepository extends CrudRepository<Logs, Integer> {

    Collection<Logs> findByDateAfterAndDateBefore(Date afterDate, Date beforeDate);
}
