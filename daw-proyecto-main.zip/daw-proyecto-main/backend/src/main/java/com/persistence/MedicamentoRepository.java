package com.persistence;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MedicamentoRepository extends CrudRepository<Medicamento, Integer> {

    List<Medicamento> findByNombre(String nombre);

}
