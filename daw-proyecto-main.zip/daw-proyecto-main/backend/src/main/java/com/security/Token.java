package com.security;

import com.persistence.Medico;
import com.persistence.Usuario;
import com.utils.TipoUsuarioEnum;

public class Token {

    private Usuario usuario;
    private TipoUsuarioEnum tipo;
    private long time;


    public Token(Usuario usuario) {
        this(usuario, System.currentTimeMillis());
    }

    public Token(Usuario usuario, long time) {
        this.usuario = usuario;
        this.tipo = usuario instanceof Medico ? TipoUsuarioEnum.MEDICO : TipoUsuarioEnum.PACIENTE;
        this.time = time;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public TipoUsuarioEnum getTipo() {
        return tipo;
    }

    public void setTipo(TipoUsuarioEnum tipo) {
        this.tipo = tipo;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public void refresh() {
        this.time = System.currentTimeMillis();
    }

}
