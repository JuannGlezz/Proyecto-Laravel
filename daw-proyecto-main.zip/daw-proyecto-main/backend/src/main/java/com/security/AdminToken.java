package com.security;

import com.persistence.Paciente;
import com.persistence.Medico;
import com.persistence.Usuario;
import com.utils.TipoUsuarioEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class AdminToken {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminToken.class);

    private long timeLive = 100 * 60 * 1000; //min * seg * milis
    private Map<UUID, Token> mapLive;

    public AdminToken() {
        this.mapLive = new ConcurrentHashMap<>();
    }


    public UUID addToken(Usuario usuario) {

        Token t = new Token(usuario);

        UUID key = UUID.randomUUID();
        mapLive.put(key, t);
        return key;
    }

    public Medico isValidTokenMedico(UUID key) {

        return (Medico) isValidToken(key, TipoUsuarioEnum.MEDICO);
    }

    public Paciente isValidTokenPaciente(UUID key) {

        return (Paciente) isValidToken(key, TipoUsuarioEnum.PACIENTE);
    }

    public Usuario isValidToken(UUID key, TipoUsuarioEnum tipo) {

        if (mapLive.containsKey(key)) {
            Token token = mapLive.get(key);
            if (tipo.equals(token.getTipo())) {
                if (System.currentTimeMillis() - token.getTime() < timeLive) {
                    token.refresh();
                    return token.getUsuario();
                } else {
                    mapLive.remove(key);
                }
            }
        }
        return null;
    }


    public boolean remove(UUID key) {

        if (mapLive.containsKey(key)) {
            mapLive.remove(key);
            return true;
        }

        return false;
    }

    public String getLogin(UUID key) {
        if (mapLive.containsKey(key)) {
            return mapLive.get(key).getUsuario().getNombre();
        }
        LOGGER.error("No se puede obtener el usuario del token");
        return "";
    }

}
