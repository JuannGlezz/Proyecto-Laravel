package com.utils;

public enum MSG {
    NOT_PERM("El usuario no tiene permisos"),
    PATIENT_EXIST("Ya existe un paciente con este DNI/NIE"),
    PATIENT_NOT_EXIST("No existe ningún paciente con el ID especificado");


    private String msg;

    MSG(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }
}
