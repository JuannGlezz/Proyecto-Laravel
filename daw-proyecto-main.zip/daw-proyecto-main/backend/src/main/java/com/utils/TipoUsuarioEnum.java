package com.utils;

public enum TipoUsuarioEnum {

    MEDICO,
    PACIENTE;

}
