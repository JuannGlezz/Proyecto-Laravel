package com.utils;

public enum CitaStatusEnum {

    ABIERTA ,
    CERRADA;

    public static CitaStatusEnum getByName(String name) {
        for (CitaStatusEnum status : CitaStatusEnum.values()) {
            if (name.equals(status.name())) {
                return status;
            }
        }
        return null;
    }
}
