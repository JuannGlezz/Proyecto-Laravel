package com.utils;

import com.persistence.Logs;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {

    public static int NOT_USED = 1;
    public static int USED = 1;

    private static final String dateFormat="dd/mm/yyyy";

    private static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);


    public static SimpleDateFormat getDateFormat()
    {
        return simpleDateFormat;
    }

    public static Logs buildLine(String user, String desc)
    {
        Logs line = new Logs();
        line.setUser(user);
        line.setDate(new Date());
        line.setDescripcion(desc);
        return line;
    }


}
