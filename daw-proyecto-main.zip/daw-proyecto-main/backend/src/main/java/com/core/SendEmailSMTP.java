package com.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
public class SendEmailSMTP {

    private static final Logger LOGGER = LoggerFactory.getLogger(SendEmailSMTP.class);

    @Value("${spring.mail.username}")
    String account;

    @Autowired
    JavaMailSender javaMailSender;

    public static void main(String[] args) {
        // for example, smtp.mailgun.org
    }

    public void sendMail(String from, String msg, String subject, Boolean copyUser) {

        try {

            SimpleMailMessage mailMessage = new SimpleMailMessage();

            // Setting up necessary details
            mailMessage.setFrom(account);
            mailMessage.setTo(account);
            if (copyUser) {
                mailMessage.setCc(from);
            }
            mailMessage.setText( msg );
            mailMessage.setSubject(subject +", Correo - "+from );

            // Sending the mail
            javaMailSender.send(mailMessage);

            LOGGER.info("Correo enviado a {}", account);

        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error("No se puede enviar el mensaje: {}, {}", msg, e.getMessage());
        }

    }

}
