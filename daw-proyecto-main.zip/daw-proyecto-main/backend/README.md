# Backend centro-medico

Instrucciones para arrancar el Backend en local

## Configuración IntelliJ 

Comando (ejecutar en la carpeta raíz): 
```
spring-boot:run
```

## Datos de acceso BBDD

Estos datos se configuran en el fichero "application.properties" de la carpeta "resources":

- Tipo: **MySQL**
- Host: **localhost**
- Puerto: **3306**
- BBDD: **proyecto**
- Usuario: **root**
- Password: 
