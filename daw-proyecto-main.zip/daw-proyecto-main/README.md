# Proyecto Fin de Ciclo
## Desarrollo de aplicaciones web - Curso 2022/23

Este proyecto ha sido desarrollado usando varias tecnologías, tanto de Backend como de Frontend.

A continuación se detallan las instrucciones para poder ejecutar este proyecto:

<br>

# Frontend

Este proyecto se ha desarrollado con Vue 3 y Vite: https://vitejs.dev/guide/

## Configuración de IDE recomendada

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (desactivar Vetur) + [TypeScript Vue Plugin (Volar)](https://marketplace.visualstudio.com/items?itemName=Vue.vscode-typescript-vue-plugin).

## Personalizar configuración

Ver [Guía de configuración de Vite](https://vitejs.dev/config/).

## Inicializar el proyecto (instalar dependencias)

```sh
npm install
```

### Compilar con "hot-reload" en local

```sh
npm run dev
```
<!--
### Compile and Minify for Production

```sh
npm run build
```
-->
### Ejecutar tests unitarios con [Vitest](https://vitest.dev/)

```sh
npm run test:unit
```

### Ejecutar tests End-to-End con [Cypress](https://www.cypress.io/)

```sh
npm run test:e2e:dev
```
<!--
This runs the end-to-end tests against the Vite development server.
It is much faster than the production build.

But it's still recommended to test the production build with `test:e2e` before deploying (e.g. in CI environments):

```sh
npm run build
npm run test:e2e
```
-->
### Validación del código con [ESLint](https://eslint.org/)

```sh
npm run lint
```


# Backend

Instrucciones para arrancar el Backend en local

## Configuración IntelliJ 

Comando (ejecutar en la carpeta raíz): 
```
mvn spring-boot:run
```

También se puede utilizar un IDE para la ejecución:

### VS Code
Es recomendable instalar la extensión [Extension Pack for Java](https://marketplace.visualstudio.com/items?itemName=vscjava.vscode-java-pack), la cual nos permite ejecutar el proyecto simplemente con un "click derecho" desde el fichero principal de la aplicación:
> backend\src\main\java\com\core\Application.java

## Datos de acceso BBDD

Estos datos se configuran en el fichero "application.properties" de la carpeta "resources":

- Tipo: **MySQL**
- Host: **localhost**
- Puerto: **3306**
- BBDD: **proyecto**
- Usuario: **root**
- Password: 

Por defecto, el proyecto arranca la conexión con BBDD en modo "update", esto quiere decir que si hay algún cambio en las entidades (por ejemplo, se añade algún campo nuevo), estas se actualizarán en la BBDD automáticamente.

Si se quiere inicializar la BBDD por primera vez, es recomendable cambiar esta configuración para ponerlo en modo "create".

Esto también se puede configurar en el fichero "application.properties", con la siguiente propiedad:
```
spring.jpa.hibernate.ddl-auto
```


Realizado por:
- [Juan González Andújar](https://github.com/chetoe)
- [Jose Antonio Gil Montero](https://github.com/josegilmon)
