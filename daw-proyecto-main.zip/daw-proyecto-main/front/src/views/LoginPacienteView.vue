<script setup>
import { reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()

const state = reactive({
  documento: '',
  password: '',
  msg: '',
  showPassword: false
})

function isValidForm () {
  return isValidDocument(state.documento) && state.password
}

function isValidDocument (document) {
  const regExpDNI = /^\d{8}[a-zA-Z]$/
  const regExpNIE = /^[a-zA-Z]\d{7}[a-zA-Z]$/
  return regExpDNI.test(document) || regExpNIE.test(document)
}

function login () {
  if (isValidForm()) {
    authStore.loginPaciente(state.documento, state.password).then(
      (response) => {
        console.log(response)
        authStore.storeTokenPaciente(response.data)
        router.push('/paciente')
      },
      () => {
        state.msg = 'Nombre de usuario o contraseña no válidos'
      }
    )
  }
}
</script>

<template>
  <div class="level" @keydown.enter="send">
    <div class="level-item">
      <section class="section is-medium">
        <article class="notification">
          

          <div class="field">
            <label class="label">DNI/NIE</label>
            <div class="control has-icons-left">
              <input class="input" type="text" placeholder="Introduzca su DNI o NIE" maxlength="10"
                     v-model="state.documento" validation-message="Campo obligatorio" required />
              <span class="icon is-small is-left">
                <i class="fas fa-user"></i>
              </span>
            </div>
          </div>

          <div>
            <div class="field">
              <label class="label">Contraseña</label>
              <p class="control has-icons-left">
                <input class="input" type="password" placeholder="Contraseña" v-model="state.password"
                  validation-message="Campo obligatorio" required />
                <span class="icon is-small is-left">
                  <i class="fas fa-lock"></i>
                </span>
              </p>
            </div>
            <div class="field has-text-centered">
              <p class="control">
                <button @click="login" class="button is-success" :disabled="!isValidForm()">
                  Login
                </button>
              </p>
            </div>
          </div>
          <p class="help is-danger" v-if="state.msg" v-html="state.msg"></p>
          <p class="is-size-7 has-text-centered pt-5">Si no está registrado, puede hacerlo desde <a href='/register'>este enlace</a></p>
        </article>
      </section>
    </div>
  </div>
</template>

<style lang="scss" scoped>
section {
  width: 400px;

  .error {
    border-radius: 5px;
  }
}
</style>
