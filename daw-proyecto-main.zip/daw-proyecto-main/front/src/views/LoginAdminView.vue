<script setup>
import { reactive } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const authStore = useAuthStore()
const router = useRouter()

const state = reactive({
  username: '',
  password: '',
  msg: '',
  showPassword: false
})

function isValidForm () {
  return state.username && state.password
}

function login () {
  if (isValidForm()) {
    authStore.login(state.username, state.password)
      .then((response) => {
        authStore.storeTokenAdmin(response.data)
        router.push('/admin')
      }, () => {
        state.msg = 'Nombre de usuario o contraseña no válidos'
        router.push('/login');
      })
  }
}
</script>

<template>
  <div class="level" @keydown.enter="send">
    <div class="level-item">
      <section class="section is-medium">
        <article class="notification">


          <div class="field">
            <label class="label">Usuario</label>
            <div class="control has-icons-left">
              <input
                  class="input"
                  type="text"
                  placeholder="Nombre de usuario"
                  maxlength="50"
                  v-model="state.username"
                  validation-message="Campo obligatorio"
                  required
              />
              <span class="icon is-small is-left">
                <i class="fas fa-user"></i>
              </span>
            </div>
          </div>

          <div class="field">
            <label class="label">Password</label>
            <p class="control has-icons-left">
              <input
                  class="input"
                  type="password"
                  placeholder="Contraseña"
                  v-model="state.password"
                  validation-message="Campo obligatorio"
                  required
              />
              <span class="icon is-small is-left">
                <i class="fas fa-lock"></i>
              </span>
            </p>
          </div>
          <div class="field has-text-centered">
            <p class="control">
              <button
                  @click="login()"
                  class="button is-success"
                  :disabled="!isValidForm()">
                Login
              </button>
            </p>
          </div>
          
   <p class="help is-danger" v-if="state.msg" v-html="state.msg"></p>
        </article>
      </section>
    </div>
  </div>
</template>

<style lang="scss" scoped>
section {
  width: 400px;

  .error {
    border-radius: 5px;
  }
}
</style>
