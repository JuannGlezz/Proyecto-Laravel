<script setup>
import MenuItem from '@/components/MenuItem.vue'
import MenuContent from '@/components/MenuContent.vue'
import PacienteComponent from '@/components/medico/PacienteComponent.vue'
import CalendarComponent from '@/components/medico/CalendarComponent.vue'
import ListaCitasComponent from '@/components/medico/ListaCitasComponent.vue'

import * as dayjs from 'dayjs'
dayjs.locale('es')

const today = dayjs()

function itemSelected (item) {
  console.log('After callback', item)
}

</script>

<template>
  <div class="box">

    <aside class="menu">
      <MenuItem title="calendario" @select="itemSelected"></MenuItem>
      <MenuItem title="pacientes" @select="itemSelected"></MenuItem>
      <MenuItem title="consultas" @select="itemSelected"></MenuItem>
    </aside>

    <article class="content">
      <MenuContent title="calendario">
        <CalendarComponent :year="today.year()" :month="today.month()"></CalendarComponent>
      </MenuContent>

      <MenuContent title="pacientes">
        <PacienteComponent></PacienteComponent>
      </MenuContent>

      <MenuContent title="consultas">
        <ListaCitasComponent></ListaCitasComponent>
      </MenuContent>
    </article>
  </div>
</template>

<style lang="scss" scoped>
.box {
  display: grid;
  grid-template-columns: 20% 1fr;

  .content {
    border-left: 1px solid rgb(72, 199, 142);
    padding-left: 1rem;
  }
}

</style>
