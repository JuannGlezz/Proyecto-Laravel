<script setup>

import { computed, reactive } from 'vue'
import { useMainStore } from '@/stores/main'

const mainStore = useMainStore()

const state = reactive({
  nombre: '',
  email: '',
  mensaje: '',
  cc: false
})

const validForm = computed(() => !!state.nombre && !!state.email && !!state.mensaje && validMail())

function validMail () {
  const re = /^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/
  return re.test(state.email)
}

function enviarMensaje () {
  mainStore.enviarMensaje(state).then(() => {
    alert('Su mensaje se ha enviado correctamente')
    state.nombre = ''
    state.email = ''
    state.mensaje = ''
    state.cc = false
  })
}

</script>

<template>

  <section class="section columns">
    <div class="container has-text-centered column is-three-quarters">
      <h2 class="title">Contacte con nosotros</h2>

      <div class="field is-horizontal">
        <div class="field-body">
          <div class="field">
            <p class="control has-icons-left">
              <input class="input" type="text" placeholder="Nombre" name="name" v-model="state.nombre" required>
              <span class="icon is-small is-left">
                <i class="fas fa-user"></i>
              </span>
            </p>
          </div>
          <div class="field">
            <p class="control has-icons-left has-icons-right">
              <input class="input" type="email" placeholder="Email" name="email" v-model="state.email" required>
              <span class="icon is-small is-left">
                <i class="fas fa-envelope"></i>
              </span>
            </p>
          </div>
        </div>
      </div>

      <div class="field">
        <div class="control">
          <textarea class="textarea" placeholder="Escriba aquí su consulta" name="mensaje" v-model="state.mensaje" required></textarea>
        </div>
      </div>

      <div class="field">
        <label class="checkbox has-text-grey-light">
          <input type="checkbox" v-model="state.cc">
          Enviar una copia del mensaje a mi correo electrónico
        </label>
      </div>

      <button type="button" class="button is-primary bulma-control-mixin" @click="enviarMensaje()" :disabled="!validForm">
        Enviar Mensaje
      </button>
    </div>
  </section>

</template>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>
