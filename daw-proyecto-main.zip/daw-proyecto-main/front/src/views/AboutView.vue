<template>
  <div class="columns mt-5">
    <div class="verde column is-9 columns">
      <div class="container verde is-align-items-center column">

        <div class="column">
          <h4 class=""><span>Email</span></h4>
          <div class="verde">
            <p>
              <a class="is-text-white" href="./contact">
                <p>proyectodawjj@gmail.com</p>
                Si quiere dejar un mensaje, haga clic aqui
              </a>
            </p>
          </div>
        </div>

        <div class="column">
          <h4 class=""><span>Teléfono</span></h4>
          <div class="">
            <p>918 67 43 38</p>
          </div>
        </div>

        <div class="column">
          <h4 class=""><span>Horarios</span></h4>
          <div class="">
            <p>08:00-21:00</p>
          </div>
        </div>

        <div class="column">
          <h5 class=""><span>Dirección</span></h5>
          <div class="">
            <p>Oficinas Centrales</p>
            <h6>C. de Francisco Chico Mendes, 4, 28108<br>Alcobendas, Madrid</h6>
          </div>
        </div>
      </div>

      <div id="map" class="column mapa my-auto">
        <img src="http://localhost:8080/api/mapa" alt="Ubicación" />
      </div>

    </div>
    <div class="column is-3">
      <img class="mx-auto is-pulled-right" src="../assets/nosotros.jpg" alt="Nosotros">
    </div>
  </div>
</template>

<style lang="scss">
a {
  color: white;

  &:visited {
    color: white;
  }
}

.verde {
  background-color: rgb(80, 196, 140);
  color: white;
}

img {
  max-height: 500px;
}

@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>
