<script setup>
import { reactive } from 'vue'
import { useMainStore } from '@/stores/main'

import dayjs from 'dayjs'
dayjs.locale('es')

const mainStore = useMainStore()
mainStore.getNoticias()

const state = reactive({
  noticiaActual: 0,
  disableAnterior: true,
  disableSiguiente: false
})

function anterior () {
  state.noticiaActual--
  state.disableSiguiente = false
  if (state.noticiaActual === 0) {
    state.disableAnterior = true
  }
}

function siguiente () {
  state.noticiaActual++
  state.disableAnterior = false
  if (state.noticiaActual === mainStore.noticias.length - 2) {
    state.disableSiguiente = true
  }
}

</script>

<template>
  <div class="container my-6">
    <div class="columns">
      <div class="banner column p-0 ml-3">
        <img src="../assets/banner_home.jpg" alt="Centro Médico La Paz">
      </div>
      <div class="column welcome ml-5 borde">
        <h1 class="is-size-4">Bienvenido al Centro Médico La Paz</h1>
        <div class="mt-6">
          El centro médico La Paz es uno de los más avanzados de la zona.
          Disponemos de las consultas más modernas, con la última tecnología en medicina y con los tratamientos más
          novedosos.
          Además, en nuestro centro podrá encontrar a su disposición a algunos de los mejores médicos del país, que le
          brindarán la mejor atención posible.
        </div>
        <div class="mt-6">
          Desde nuestra web, usted podrá concertar una cita con cualquiera de ellos y gestionarla fácilmente desde
          nuestra área privada de paciente,
          así como consultarnos cualquier duda que usted pueda tener sobre nuestros servicios o nuestro personal.
        </div>
      </div>
    </div>
  </div>

  <section class="section has-background-light is-clipped">
    <div class="container">
      <h2 class="title">Últimas noticias en medicina</h2>
      <div class="columns noticias" :class="'step' + state.noticiaActual">
        <div class="column is-5" v-for="noticia in mainStore.noticias" :key="noticia.id">
          <div class="noticia">
            <a :href="noticia.enlace" target="_blank">
              <div class="imagen">
                <img :src="noticia.imagen" alt="">
              </div>
              <div class="titulo p-2 is-size-4 has-text-white has-background-info">
                {{ noticia.titulo }}
                <span class="is-size-7 is-pulled-right">{{ dayjs(noticia.fecha).format('dddd, D [de] MMMM - HH:mm') }}</span>
              </div>
            </a>

          </div>
        </div>
      </div>

      <div class="columns is-multiline is-justify-content-space-between is-align-items-center">
        <div class="column is-9 mr-4 has-background-grey-light p-0">
          <div class="column is-3 has-background-primary p-0"></div>
        </div>
        <div class="column is-2 ml-auto is-flex is-justify-content-end is-align-items-center">
          <button class="button is-primary is-medium"
                  :disabled="state.disableAnterior"
                  @click="anterior()">
            <span class="icon">
              <i class="fas fa-chevron-left"></i>
            </span>
          </button>
          <button class="button is-primary is-medium ml-3"
                  :disabled="state.disableSiguiente"
                  @click="siguiente()">
            <span class="icon">
              <i class="fas fa-chevron-right"></i>
            </span>
          </button>
        </div>
      </div>

    </div>
  </section>
</template>

<style lang="scss">
.borde{
  border-color: green;
}

.banner {
  /* background: url('../assets/banner_home.jpg') center;
  background-position: 50% 50%; */
  border-radius: 10px;
  width: 720px;
  height: 360px;
  overflow: hidden;
  text-align: center;
  display: flex;
  justify-content: center;
  align-items: center;

  img {
    border-radius: 10px;
    height: 100%;
    margin: 0 -50%;
    max-width: initial;
  }
}

.welcome {
  text-align: justify;
}

.noticias {
  transition: all 0.5s ease-in-out;

  &.step1 {
    transform: translate(-570px, 0);
  }
  &.step2 {
    transform: translate(-1140px, 0);
  }
  &.step3 {
    transform: translate(-1710px, 0);
  }
  &.step4 {
    transform: translate(-2280px, 0);
  }

}

.noticia {

  .imagen {
    height: 370px;
    overflow: hidden;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;

    img {
      height: 370px;
      margin: -100%;
      max-width: initial;
    }
  }

  .titulo {
    height: 130px;

    span {
      position: absolute;
      bottom: 10px;
      right: 10px;
    }
  }
}

@media screen and (max-width: 800px) {
  h2, h3, h4, p {
    margin: auto;
    width: 60%;

  }
}
</style>
