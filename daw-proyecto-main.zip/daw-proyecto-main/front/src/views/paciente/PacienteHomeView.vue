<script setup>
import { reactive } from 'vue'
import { useAuthStore } from '@/stores/auth'
import ListaCitasComponent from '@/components/paciente/ListaCitasComponent.vue'
import CitaComponent from '@/components/paciente/CitaComponent.vue'
import EditPacienteComponent from '@/components/paciente/EditPacienteComponent.vue'

const CONSULTAR_CITAS = 'consultar_citas'
const CREAR_CITA = 'crear_cita'
const EDITAR_PACIENTE = 'editar_paciente'

const store = useAuthStore()

const state = reactive({
  tag: CONSULTAR_CITAS
})

function editarCita () {
  state.tag = CREAR_CITA
}

</script>

<template>
  <div class="">

    <div class="has-text-centered">
      <span class="tag is-normal is-large">
        Hola <span class="has-text-weight-bold ml-2">{{ store.tokenPaciente.nombre }}</span>
        </span>
    </div>

    <br>

    <div class="box">
      <aside class="menu">
        <p class="menu-label"
          :class="{ 'selected': state.tag === CONSULTAR_CITAS }"
          @click="state.tag = CONSULTAR_CITAS">Mis citas</p>
        <p class="menu-label"
          :class="{ 'selected': state.tag === CREAR_CITA }"
          @click="state.tag = CREAR_CITA">Nueva cita</p>
        <p class="menu-label"
          :class="{ 'selected': state.tag === EDITAR_PACIENTE }"
          @click="state.tag = EDITAR_PACIENTE">Editar datos personales</p>
      </aside>

      <article class="content">
        <div v-if="state.tag === CONSULTAR_CITAS">
          <ListaCitasComponent @edit="editarCita"></ListaCitasComponent>
        </div>

        <div v-if="state.tag === CREAR_CITA">
          <CitaComponent></CitaComponent>
        </div>

        <div v-if="state.tag === EDITAR_PACIENTE">
          <EditPacienteComponent></EditPacienteComponent>
        </div>
      </article>
    </div>
  </div>
</template>

<style lang="scss" scoped>

.box {
  display: grid;
  grid-template-columns: 20% 1fr;

  .menu-label {
    margin: 0 auto;
    padding: 0.5rem 0 0.5rem 1rem;
    cursor: pointer;

    &:hover {
      text-decoration: underline;
    }
  }

  .selected {
    color: white;
    background-color: rgb(72, 199, 142);
    /* box-shadow: rgba(72, 199, 142, 1) 0px 8px 24px;*/
  }

  .content {
    border-left: 1px solid rgb(72, 199, 142);
    padding-left: 1rem;
  }
}
.action {
  padding: 1rem;

  button {
    font-size: 4rem;
    border-radius: 15px;
  }
}

</style>
