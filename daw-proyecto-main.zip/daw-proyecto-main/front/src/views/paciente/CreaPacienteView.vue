<script setup>
import { computed, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useMainStore } from '@/stores/main'
import { usePacienteStore } from '@/stores/paciente'

import dayjs from 'dayjs'
dayjs.locale('es')

const router = useRouter()
const store = usePacienteStore()

const state = reactive({
  documento: '',
  password: '',
  repetirPassword: '',
  nombre: '',
  apellidos: '',
  fechaNacimiento: null,
  telefono: null,
  genero: null,
  terms: false
})

const isValidDocument = ref(true)
const isValidPassword = ref(true)
const isSamePassword = ref(true)

const isValidForm = computed(() => {
  return state.documento && state.password && state.repetirPassword &&
      state.password === state.repetirPassword &&
      state.nombre && state.apellidos &&
      state.fechaNacimiento && state.telefono &&
      state.genero && state.terms &&
      isValidDocument.value && isValidPassword.value && isSamePassword.value
})

function getErrorMsg (err) {
  if (err && err.response && err.response.data && err.response.data.message) {
    return err.response.data.message
  }
  return 'Error desconocido, por favor inténtelo de nuevo más tarde.'
}

function submitForm () {
  if (isValidForm.value) {
    store.savePaciente(state)
      .then(
        (result) => {
          alert('Datos guardados correctamente')
          close()
        },
        (err) => {
          alert(getErrorMsg(err))
        }
      )
  }
}

function showTermsAndConditions () {
  const mainStore = useMainStore()
  mainStore.setModal('TERMS', null)
}

function close () {
  router.push('/login-paciente')
}

function validaDocumento () {
  const regExpDNI = /^\d{8}[a-zA-Z]$/
  const regExpNIE = /^[a-zA-Z]\d{7}[a-zA-Z]$/
  isValidDocument.value = !state.documento || (state.documento.length === 9 && (regExpDNI.test(state.documento) || regExpNIE.test(state.documento)))
}

function validaPassword () {
  const regExpPswd = /^(?=.*\d)(?=.*[a-záéíóúüñ]).*[A-ZÁÉÍÓÚÜÑ]/
  isValidPassword.value = !state.password || regExpPswd.test(state.password)
  isSamePassword.value = !state.password || !state.repetirPassword || state.password === state.repetirPassword
}

</script>

<template>
  <div class="container">
    <article class="">
      <nav class="panel" aria-label="acceso">
        <p class="panel-heading">Datos de acceso</p>
        <div class="columns panel-block is-multiline">
          <div class="field column is-4 mb-0">
            <label class="label">DNI/NIE</label>
            <div class="control has-icons-left has-icons-right">
              <input v-model="state.documento"
                     class="input"
                     placeholder="DNI/NIE"
                     type="text"
                     @change="validaDocumento()"
                     required>
              <span class="icon is-small is-left">
                <i class="fas fa-user"></i>
              </span>
            </div>
          </div>
          <div class="field column is-4 mb-0">
            <label class="label">Contraseña</label>
            <div class="control">
              <input v-model="state.password"
                     class="input"
                     placeholder="Contraseña"
                     type="password"
                     title="Debe contener almenos una mayúscula, una minúscula y un dígito"
                     @change="validaPassword()"
                     required>
            </div>
          </div>
          <div class="field column is-4 mb-0">
            <label class="label">Repetir contraseña</label>
            <div class="control">
              <input v-model="state.repetirPassword"
                     class="input"
                     placeholder="Repetir Contraseña"
                     type="password"
                     @change="validaPassword()"
                     required>
            </div>
          </div>
          <div class="column is-4 p-0">
            <span class="help is-danger column is-12 pt-0" v-if="!isValidDocument">El documento no es un DNI/NIE válido</span>
          </div>
          <div class="column is-8 p-0">
            <span class="help is-danger column is-12 pt-0" v-if="!isValidPassword">La contraseña debe contener al menos una mayúscula, una minúscula y un dígito</span>
            <span class="help is-danger column is-12 pt-0" v-if="isValidPassword && !isSamePassword">Las contraseñas no coinciden</span>
          </div>
        </div>
      </nav>

      <nav class="panel" aria-label="datos">
        <p class="panel-heading">Datos personales</p>

        <div class="columns panel-block">
          <div class="field column">
            <label class="label">Nombre</label>
            <div class="control">
              <input type="text"
                     placeholder="Nombre"
                     class="input"
                     v-model="state.nombre"
                     required>
            </div>
          </div>
        </div>
        <div class="columns panel-block">
          <div class="field column">
            <label class="label">Apellidos</label>
            <div class="control">
              <input type="text"
                     placeholder="Apellidos"
                     class="input"
                     v-model="state.apellidos"
                     required>
            </div>
          </div>
        </div>
        <div class="columns panel-block">
          <div class="field column is-4">
            <label class="label">Fecha de nacimiento</label>
            <div class="control">
              <input type="date"
                     class="input"
                     :max="dayjs().format('YYYY-MM-DD')"
                     v-model="state.fechaNacimiento"
                     required>
            </div>
          </div>

          <div class="field column is-4">
            <label class="label">Teléfono</label>
            <div class="control">
              <input type="tel"
                     placeholder="Teléfono"
                     class="input"
                     v-model="state.telefono">
            </div>
          </div>

          <div class="field column is-4">
            <label class="label">Género</label>
            <div class="control">
              <label class="radio">
                <input type="radio" value="M" v-model="state.genero">
                Masculino
              </label>
              <label class="radio">
                <input type="radio" value="F" v-model="state.genero">
                Femenino
              </label>
            </div>
            <p class="help is-danger column is-12 pt-0">
              &nbsp;<!--Por favor, seleccione una opción-->
            </p>
          </div>
        </div>

      </nav>
      <div class="column is-12 p-0">
            <!--span class="help is-danger column is-12 pt-0 has-text-centered" v-if="!state.terms">Debe aceptar los términos y condiciones</span-->
          </div>
      <div class="field is-grouped is-justify-content-center">
        <div class="control pt-4">
          <label class="checkbox">
            <input type="checkbox" v-model="state.terms" class="is-12">
            Estoy de acuerdo con los <a href="#" class="has-text-primary has-background-white" @click="showTermsAndConditions()">términos y condiciones</a>
          </label>
        </div>

      </div>

      <div class="field is-grouped is-justify-content-center">
        <div class="control">
          <button class="button is-link is-info" @click="submitForm()" :disabled="!isValidForm">Guardar</button>
        </div>
        <div class="control">
          <button class="button is-link is-danger" @click="close()">Cancelar</button>
        </div>
      </div>
    </article>
  </div>
</template>

<style lang="scss" scoped>
  .panel-block:not(:last-child) {
    border: none;
    margin-bottom: 0;
  }

  .container {
    width: 80%;
  }
</style>
