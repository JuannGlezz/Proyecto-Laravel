<script setup>
import { RouterLink, RouterView } from 'vue-router'
import ModalComponent from '@/components/ModalComponent.vue'
import AccessComponent from '@/components/AccessComponent.vue'
import FooterComponent from '@/components/FooterComponent.vue'
import ToastComponent from '@/components/ToastComponent.vue'

function showToast () {
  window.dispatchEvent(new CustomEvent('toast', { detail: 'Hola esto es un mensaje largo para ver como se comporta el toast' }))
}
</script>

<template>
    <header class="columns">
      <div class="column title m-0 has-text-centered is-3" @click="showToast()">
        <div>
          <div>Centro</div>
          <span>+</span>
        </div>
        <div>Médico</div>
      </div>
      <div class="menu column is-6 has-text-centered">
        <nav>
          <RouterLink to="/">Inicio</RouterLink>
          <RouterLink to="/services">Servicios</RouterLink>
          <RouterLink to="/about">Nosotros</RouterLink>
          <RouterLink to="/contact">Contacto</RouterLink>
        </nav>
      </div>
      <div class="column is-3">
        <AccessComponent></AccessComponent>
      </div>
    </header>

    <div class="content">
      <RouterView />

      <ModalComponent />
    </div>

    <ToastComponent></ToastComponent>
    <FooterComponent></FooterComponent>
</template>

<style lang="scss" scoped>
  .main {
    display: grid;
    min-height: 100vh;
    grid-template-rows: auto 1fr auto;
  }
  header {
    height: 200px;
    padding: 25px;
    background-color: rgba(72, 199, 142, 1);
    border-radius: 0 0 40% 40%;
    /* center title */
    display: grid;
    grid-template-columns: 25% 1fr 25%;

    .title {
      div {
        color: white;
        font-size: 1.5em;
        font-weight: bold;
        text-transform: uppercase;
      }

      div:first-child {
        font-size: 1em;

        div {
          display: inline;
        }

        span {
          display: inline-block;
          background-color: white;
          color: rgba(72, 199, 142, 1);
          font-weight: bold;
          font-size: 2em;
          height: 48px;
          width: 44px;
          line-height: 36px;
          margin-left: 12px;
        }
      }
    }
    .menu {
      display: flex;
    }
  }

  nav {
    width: 100%;
    font-size: 1.2em;
    text-align: center;
    margin-top: 4rem;
  }

  nav a.router-link-exact-active {
    color: var(--color-text);
  }

  nav a.router-link-exact-active:hover {
    background-color: transparent;
  }

  nav a {
    color: var(--vt-c-white);
    display: inline-block;
    padding: 0 1rem;
    border-left: 1px solid var(--color-border);

    &:hover {
      color: green;
      background-color: transparent;
    }
  }

  nav a:first-of-type {
    border: 0;
  }

  .content {
    flex: 1;
    max-width: 80%;
    min-width: 1280px;
    margin: 1rem auto 0;

    @media (max-width: 1280px) {
      max-width: 90%;
    }
  }
</style>
