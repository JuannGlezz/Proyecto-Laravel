import { defineStore } from 'pinia'
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import axios from 'axios'

export const usePacienteStore = defineStore('paciente', () => {
  const router = useRouter()

  const instance = axios.create({
    baseURL: 'http://localhost:8080/api'
  })

  instance.interceptors.request.use(function (config) {
    if (!config.headers) {
      config.headers = {}
    }
    const authStore = useAuthStore()
    if (authStore.tokenPaciente && authStore.tokenPaciente.token) {
      config.headers.token = authStore.tokenPaciente.token
    } else {
      router.push('/login-paciente')
    }
    return config
  }, function (error) {
    return Promise.reject(error)
  })

  instance.interceptors.response.use(function (response) {
    return response
  }, function (error) {
    if (error.response) {
      console.log('Not authorized')
      router.push('/login-paciente')
    }
    return Promise.reject(error)
  })

  const showModal = ref(false)
  const isPaciente = ref(false)
  const cita = reactive({
    idMedico: null,
    fecha: null
  })
  const citas = reactive([])
  const paciente = reactive({})
  const medicos = reactive([])

  function setModal (modalStatus) {
    this.showModal = modalStatus
  }
  function setIsPaciente (isPaciente) {
    this.isPaciente = isPaciente
  }
  function setCita (cita) {
    this.cita = cita
  }
  async function getCitas () {
    const result = await instance.get('/citas/paciente')
    this.citas = result.data
  }
  async function getPaciente () {
    const result = await instance.get('/pacientes/get')
    this.paciente = result.data
  }
  function savePaciente (payload) {
    return instance.post('/pacientes', { ...payload })
  }
  function updatePaciente (payload) {
    return instance.put('/pacientes', { ...payload })
  }
  async function getMedicos () {
    const result = await instance.get('/medicos')
    this.medicos = result.data
  }
  async function saveCita (payload) {
    console.log(payload)
    if (payload.id) {
      return await instance.put('/citas/' + payload.id + '/reagendar', payload)
    } else {
      return await instance.post('/citas', payload)
    }
  }

  return {
    showModal,
    isPaciente,
    cita,
    citas,
    paciente,
    medicos,
    setModal,
    setIsPaciente,
    setCita,
    getCitas,
    getPaciente,
    savePaciente,
    updatePaciente,
    getMedicos,
    saveCita
  }
})
