import { reactive } from 'vue'
import { useRouter } from 'vue-router'
import { defineStore } from 'pinia'
import { useAuthStore } from '@/stores/auth'
import { useMainStore } from '@/stores/main'
import axios from 'axios'

export const useMedicoStore = defineStore('medico', () => {
  const router = useRouter()

  const instance = axios.create({
    baseURL: 'http://localhost:8080/api'
  })

  instance.interceptors.request.use(function (config) {
    if (!config.headers) {
      config.headers = {}
    }
    const authStore = useAuthStore()
    if (authStore.tokenAdmin && authStore.tokenAdmin.token) {
      config.headers.token = authStore.tokenAdmin.token
    } else {
      router.push('/login')
    }
    return config
  }, function (error) {
    return Promise.reject(error)
  })

  instance.interceptors.response.use(function (response) {
    return response
  }, function (error) {
    if (error.response) {
      console.log('Not authorized')
      router.push('/login')
    }
    return Promise.reject(error)
  })

  const state = reactive({
    isPaciente: false,
    selectedItem: 'calendario',
    cita: null,
    citas: [],
    paciente: null,
    pacientes: []
  })

  function setIsPaciente (isPaciente) {
    this.state.isPaciente = isPaciente
  }

  function selectAdminMenuItem (item) {
    this.state.selectedItem = item
  }

  function setCita (cita) {
    this.state.cita = cita

    const store = useMainStore()
    store.setModal('CITA', cita)
  }

  async function getCitas (status) {
    this.state.citas = await instance.get('/citas?status=' + (status || '')).then(result => result.data)
  }

  async function getCita (idCita) {
    this.state.cita = await axios.get('/citas/' + idCita).then(result => result.data)
  }

  async function saveCita (payload) {
    this.state.cita = await instance.put('/citas/' + payload.id, payload).then(result => result.data)
  }

  async function getPaciente (documento) {
    this.state.paciente = await axios.get('/pacientes/' + documento).then(result => result.data)
  }

  async function getPacientes () {
    this.state.pacientes = await instance.get('/pacientes').then(result => result.data)
  }

  return {
    state,
    setIsPaciente,
    selectAdminMenuItem,
    setCita,
    getCitas,
    getCita,
    saveCita,
    getPaciente,
    getPacientes
  }
})
