import { defineStore } from 'pinia'
import axios from 'axios'

const instance = axios.create({
  baseURL: 'http://localhost:8080/api'
})

export const useAuthStore = defineStore('auth', {
  state: () => ({
    tokenAdmin: null,
    tokenPaciente: null
  }),
  actions: {
    async checkLogin () {
      let tipo = ''

      if (this.tokenAdmin) {
        tipo = 'MEDICO'
      } else if (this.tokenPaciente) {
        tipo = 'PACIENTE'
      } else {
        return false
      }

      await instance.get(
        '/token?tipo=' + tipo, {
          headers: {
            token: (this.tokenAdmin || this.tokenPaciente).token
          }
        })
        .catch(() => {
          this.storeTokenAdmin(null)
          this.storeTokenPaciente(null)
        })
    },
    storeTokenAdmin (token) {
      this.tokenAdmin = token
      window.sessionStorage.setItem('tokenAdmin', JSON.stringify(token))
    },
    storeTokenPaciente (token) {
      this.tokenPaciente = token
      window.sessionStorage.setItem('tokenPaciente', JSON.stringify(token))
    },
    login (login, password) {
      return axios.post('/login', { login, password })
      // this.storeTokenAdmin(response.data)
    },
    loginPaciente (login, password) {
      return axios.post('/login/paciente', { login, password })
      // this.storeTokenPaciente(response.data)
    },
    logout () {
      if (this.tokenAdmin) {
        instance.post('/logout', null, {
          headers: {
            token: this.tokenAdmin
          }
        })
        this.storeTokenAdmin(null)
      }
      if (this.tokenPaciente) {
        instance.post('/logout', null, {
          headers: {
            token: this.tokenPaciente
          }
        })
        this.storeTokenPaciente(null)
      }
    }
  }
})
