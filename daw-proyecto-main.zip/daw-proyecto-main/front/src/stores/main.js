import { defineStore } from 'pinia'
import axios from 'axios'

axios.defaults.baseURL = 'http://localhost:8080/api/'

export const useMainStore = defineStore('main', {
  state: () => ({
    showModal: false,
    showToast: false,
    modalData: null,
    noticias: []
  }),
  actions: {
    async getNoticias () {
      this.noticias = await axios.get('/noticias').then(result => result.data)
    },
    enviarMensaje (payload) {
      return axios.post('/contacto', { ...payload })
    },
    setModal (modalStatus, modalData) {
      this.showModal = modalStatus
      this.modalData = modalData
    }
  }
})
