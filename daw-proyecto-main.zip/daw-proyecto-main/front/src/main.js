import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { useAuthStore } from '@/stores/auth'

import App from './App.vue'
import router from './router'
import './assets/main.scss'

const app = createApp(App)

app.use(createPinia())
app.use(router)

const authStore = useAuthStore()
if (window.sessionStorage.getItem('tokenAdmin')) {
  authStore.storeTokenAdmin(JSON.parse(window.sessionStorage.getItem('tokenAdmin')))
}
if (window.sessionStorage.getItem('tokenPaciente')) {
  authStore.storeTokenPaciente(JSON.parse(window.sessionStorage.getItem('tokenPaciente')))
}

app.mount('#app')
