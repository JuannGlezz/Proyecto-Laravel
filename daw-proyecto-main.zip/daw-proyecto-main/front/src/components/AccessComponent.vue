<script setup>
import { computed } from 'vue'
import { RouterLink, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()
authStore.checkLogin()

const mostrarLogin = computed(() => !authStore.tokenAdmin && !authStore.tokenPaciente)
const rutaAreaPrivada = computed(() => authStore.tokenAdmin ? '/admin' : '/paciente')

function logout () {
  authStore.logout()
  router.push('/')
}
</script>

<template>
  <div>
    <div class="access is-flex">
      <nav>
        <div v-if='mostrarLogin'>
          <RouterLink to="/login-paciente">Acceso pacientes</RouterLink>
          <RouterLink to="/login">Acceso médicos</RouterLink>
        </div>
        <div v-else>
          <RouterLink :to="rutaAreaPrivada">Área privada</RouterLink>
          <a href="#" @click="logout()">
            Cerrar sesión
            <span class="icon">
              <i class="fas fa-door-open"></i>
            </span>
          </a>
        </div>
      </nav>
    </div>
  </div>
</template>

<style lang="scss" scoped>
  .access {

    button {
      margin-left: 1.5rem;
    }

    nav {
      width: 100%;
      font-size: 1.2em;
      text-align: center;
      margin-top: 4rem;
    }

    nav a.router-link-exact-active {
      color: var(--color-text);
    }

    nav a.router-link-exact-active:hover {
      background-color: transparent;
    }

    nav a {
      color: var(--vt-c-white);
      display: inline-block;
      padding: 0 1rem;
      border-left: 1px solid var(--color-border);

      &:hover {
        color: green;
        background-color: transparent;
      }
    }

    nav a:first-of-type {
      border: 0;
    }
  }

</style>
