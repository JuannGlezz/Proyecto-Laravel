<script setup>
import { computed, reactive } from 'vue'
import { useMedicoStore } from '@/stores/medico'
import dayjs from 'dayjs'

// const emit = defineEmits(['edit'])

const store = useMedicoStore()
store.getCitas()

const PAGE_SIZE = 3
const pages = computed(() => new Array(Math.ceil(store.state.citas.length / PAGE_SIZE)))

const state = reactive({
  pages,
  current: 0
})

function getCitas () {
  const inicio = state.current * PAGE_SIZE
  return store.state.citas.slice(inicio, inicio + PAGE_SIZE)
}

function verCita (cita) {
  store.setCita(cita)
}

</script>

<template>
  <div class="column">
    <nav class="panel" aria-label="Histórico">
      <p class="panel-heading">Histórico de consultas</p>
      <div class="panel-block mx-2 is-flex is-flex-direction-column">

        <table class="table" aria-label="Lista de citas">
          <thead>
          <tr>
            <th>Fecha</th>
            <th>Paciente</th>
            <th>Estado</th>
            <th></th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="cita in getCitas()" :key="cita.id">
            <td>{{ dayjs(cita.fecha).format('dddd, DD [de] MMMM [de] YYYY, HH:mm') }}</td>
            <td>{{ cita.paciente.nombre + ' ' + cita.paciente.apellidos }}</td>
            <td>{{ cita.status || '-' }}</td>
            <td>
              <button class="button is-info is-small"
                      :class="{ 'is-light': cita.status === 'CERRADA' }"
                      :title="cita.status === 'CERRADA' ? 'Ver cita' : 'Editar cita'">
                <span class="icon" @click="verCita(cita)" alt="Ver cita">
                  <i class="fas" :class="cita.status === 'CERRADA' ? 'fa-eye' : 'fa-edit'"></i>
                </span>
              </button>
            </td>
          </tr>
          </tbody>
        </table>

        <div class="container">
          <nav class="pagination is-centered" role="navigation" aria-label="pagination">
            <ul class="pagination-list">
              <li v-for="(page, index) in state.pages" :key="index">
                <a class="pagination-link" :class="{ 'is-current': index === state.current }" @click="state.current = index">{{ index + 1 }}</a>
              </li>
            </ul>
          </nav>
        </div>

      </div>
    </nav>

  </div>
</template>
