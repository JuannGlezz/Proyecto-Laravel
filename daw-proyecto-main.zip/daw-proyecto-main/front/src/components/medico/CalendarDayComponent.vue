<script setup>
import { useMedicoStore } from '@/stores/medico'

import dayjs from 'dayjs'
dayjs.locale('es')

const store = useMedicoStore()

const props = defineProps(['citas', 'day', 'index'])
const today = dayjs()

function openCita (cita) {
  store.setCita(cita)
  store.setModal(true)
}

function printCita (cita) {
  const fecha = dayjs(cita.fecha, '')
  return fecha.format('HH:mm') + ' - ' + cita.paciente.nombre + ' ' + cita.paciente.apellidos
}

</script>

<template>
  <div :class="{ 'first-child': !(props.index % 7), 'weekend': (props.index % 7 >= 5) , 'today': props.day === today.date() }">
    <span class="px-2">{{ props.day }}</span>
    <p class="citas">
      <a v-for="cita in citas"
         :key="cita.id"
         :title="printCita(cita)"
         v-html="printCita(cita)"
         @click="openCita(cita)"></a>
    </p>
  </div>
</template>

<style lang="scss" scoped>

div {
  border-right: 1px solid gray;
  border-bottom: 1px solid gray;
  background-color: white;
  min-width: 125px;
  height: 125px;

  &.first-child {
    border-left: 1px solid gray;
  }

  &.weekend {
    background-color: rgb(220, 220, 220);
  }

  &.today {
    background-color: lightskyblue;
  }

  .citas {
    font-size: small;
    padding: 0 5px;

    a {
      display: block;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }
  }
}

</style>
