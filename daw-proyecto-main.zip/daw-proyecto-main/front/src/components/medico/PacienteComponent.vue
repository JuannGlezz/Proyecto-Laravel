<script setup>
import { computed, reactive } from 'vue'
import { useMedicoStore } from '@/stores/medico'
import dayjs from 'dayjs'

const store = useMedicoStore()
store.getPacientes()

const state = reactive({
  search: '',
  message: 'Introduzca algún criterio de búsqueda para ver el listado de pacientes',
  pacientes: []
})

function searchPacientes () {
  const pacientes = computed(() => store.state.pacientes)

  const search = state.search.toUpperCase()

  state.pacientes = pacientes.value.filter(item => {
    const find = key => item[key].toUpperCase().indexOf(search) !== -1
    return find('nombre') || find('apellidos') || find('documento')
  })
  if (!state.pacientes.length) {
    state.message = 'No se han encontrado pacientes'
  }
}
</script>

<template>
  <div class="container">
    <nav class="panel">
      <p class="panel-heading">Pacientes</p>

      <div class="content">

        <div class="field has-addons is-justify-content-center">
          <div class="control has-icons-left">
            <input class="input"
                   type="text"
                   placeholder="Texto para buscar..."
                   alt="Buscar por nombre, apellido o DNI/NIE"
                   v-model="state.search">
            <span class="icon is-small is-left">
              <i class="fas fa-search"></i>
            </span>
          </div>
          <div class="control">
            <a class="button is-info" @click="searchPacientes()">Buscar</a>
          </div>
        </div>

        <div class="py-4">
          <p class="has-text-centered" v-if="!state.pacientes.length">{{ state.message }}</p>
          <div class="table-container" v-else>
            <table class="table is-striped is-hoverable is-fullwidth" aria-label="Listado de pacientes">
              <thead>
              <tr>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>DNI/NIE</th>
                <th><abbr title="Fecha de nacimiento">F. Nac.</abbr></th>
                <th>Género</th>
                <th>Teléfono</th>
                <th>Historial médico</th>
                <th></th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="paciente in state.pacientes" :key="paciente.documento">
                <td v-html="paciente.nombre"></td>
                <td v-html="paciente.apellidos"></td>
                <td v-html="paciente.documento"></td>
                <td>{{ dayjs(paciente.fechaNacimiento).format('DD/MM/YYYY') }}</td>
                <td v-html="paciente.genero"></td>
                <td v-html="paciente.telefono"></td>
                <td v-html="paciente.historial"></td>
                <td></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </nav>

  </div>

</template>

<style lang="scss" scoped>
.panel {
  .content {
    padding: 0 10px;
  }
}
</style>
