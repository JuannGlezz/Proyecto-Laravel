<script setup>
import { computed, reactive } from 'vue'
import { useMedicoStore } from '@/stores/medico'

import dayjs from 'dayjs'
dayjs.locale('es')

const props = defineProps(['cita'])
const emit = defineEmits(['close'])

const store = useMedicoStore()

const state = reactive({
  cita: props.cita,
  paciente: props.cita.paciente,
  medicamentos: props.cita.medicamentos,
  medicamento: { nombre: '', dosis: '', observaciones: '' },
  modoEdicion: false
})
const esEditable = computed(() => state.cita.status === 'ABIERTA')

function cerrar () {
  emit('close')
}

function anadirMedicamento () {
  state.medicamentos.push({ ...state.medicamento })
  state.medicamento = { nombre: '', dosis: '', observaciones: '' }
}

function guardarCita () {
  store.saveCita(state.cita).then(
    () => {
      alert('La cita se ha guardado correctamente')
      cerrar()
    },
    () => alert('Se ha producido un error y la cita no se ha podido guardar')
  )
}

function archivarCita () {
  if (window.confirm('¿Está seguro de que desea archivar la cita?\nUna vez archivada, la cita no se podrá editar.')) {
    state.cita.status = 'CERRADA'
    store.saveCita(state.cita)
  }
}

function reabrirCita () {
  state.cita.status = 'ABIERTA'
  store.saveCita(state.cita).then(
    () => alert('La cita se ha reabrierto correctamente'),
    () => alert('Se ha producido un error y la cita no se ha podido reabrir')
  )
}

</script>

<template>
  <article class="message">
    <div class="message-header">
      <p>Detalles de la cita -> {{ dayjs(props.cita.fecha).format('HH:mm - dddd, D [de] MMMM [de] YYYY') }}</p>
      <button class="delete" aria-label="Cerrar" @click="cerrar()"></button>
    </div>
    <div class="message-body columns is-multiline">
      <div class="column is-6">
        <div class="field">
          <label class="label">Paciente</label>
          <div class="level">
            <div class="control has-icons-left level-left level-item pr-2">
              <input class="input is-info" type="text"
                     :value="state.cita.paciente.nombre + ' ' + state.cita.paciente.apellidos"
                     disabled>
              <span class="icon is-small is-left">
                <i class="fas fa-user"></i>
              </span>
            </div>
          </div>
        </div>
        <div class="field level">
          <div class="control has-icons-left">
            <input class="input is-info" type="text"
                   :value="dayjs(state.cita.paciente.fechaNacimiento).format('DD/MM/YYYY')"
                   disabled>
            <span class="icon is-small is-left">
              <i class="fas fa-calendar"></i>
            </span>
          </div>
        </div>
        <div class="field level">
          <div class="control">
            <label class="radio">
              <input type="radio" value="M" v-model="state.cita.paciente.genero" disabled>
              Masculino
            </label>
            <label class="radio">
              <input type="radio" value="F" v-model="state.cita.paciente.genero" disabled>
              Femenino
            </label>
          </div>
        </div>
      </div>
      <div class="column is-6 historial">
        <label class="label">Historial</label>
        <div class="field">
          <div class="control">
          <textarea class="textarea is-info"
                    placeholder="Sin completar" rows="6"
                    v-model="state.cita.paciente.historial"
                    :disabled="!esEditable"
          ></textarea>
          </div>
        </div>
      </div>

      <div class="column is-full">
        <label class="label">Observaciones</label>
        <div class="field">
          <div class="control">
            <textarea class="textarea is-info"
                      placeholder="Añadir comentarios de la cita" rows="4"
                      v-model="state.cita.comentarios"
                      :disabled="!esEditable"
            ></textarea>
          </div>
        </div>
      </div>

      <div class="column is-full">
        <label class="label">Tratamiento</label>
        <div class="field box is-flex is-flex-direction-row">
          <table class="table is-flex-grow-1" v-if="esEditable || state.medicamentos.length" aria-label="Tratamiento">
            <thead>
            <tr>
              <th>#</th>
              <th>Nombre</th>
              <th>Dosis</th>
              <th>Observaciones</th>
              <th></th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="(medicamento, index) in state.medicamentos" :key="index">
              <td>{{ index + 1 }}</td>
              <td>{{ medicamento.nombre }}</td>
              <td>{{ medicamento.dosis }}</td>
              <td>{{ medicamento.observaciones }}</td>
            </tr>
            <tr v-if="esEditable">
              <td>{{ state.medicamentos.length + 1}}</td>
              <td><input type="text" class="input is-small" v-model="state.medicamento.nombre" /></td>
              <td><input type="text" class="input is-small" v-model="state.medicamento.dosis" /></td>
              <td><input type="text" class="input is-small" v-model="state.medicamento.observaciones" /></td>
              <td>
                <button class="button is-small is-info ml-5">
                  <span class="icon is-small" @click="anadirMedicamento()">
                    <i class="fas fa-add"></i>
                  </span>
                </button>
              </td>
            </tr>
            </tbody>
          </table>
          <div v-else>No se han recetado medicamentos</div>
        </div>
      </div>

      <div class="column field is-grouped is-justify-content-space-between">
        <div class="control is-pulled-left" v-if="esEditable">
          <button class="button is-link is-success" @click="guardarCita()">Guardar</button>
          <button class="button is-link ml-4" @click="archivarCita()">Archivar</button>
        </div>
        <div class="control is-pulled-right" v-else>
          <button class="button is-link is-info" @click="reabrirCita()">Reabrir</button>
        </div>
        <div class="control is-pulled-right">
          <button class="button is-link is-danger" @click="cerrar()">Cerrar</button>
        </div>
      </div>

    </div>
  </article>
</template>

<style lang="scss" scoped>

.message {
  border-radius: 8px;

  .historial {
    max-height: 185px;
    overflow: visible;
  }
}

</style>
