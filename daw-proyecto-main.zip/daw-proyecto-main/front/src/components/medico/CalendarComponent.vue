<script setup>
import { computed, reactive } from 'vue'
import { useMedicoStore } from '@/stores/medico'
import CalendarDayComponent from '@/components/medico/CalendarDayComponent.vue'

import dayjs from 'dayjs'
import 'dayjs/locale/es'
dayjs.locale('es')

const props = defineProps(['month', 'year'])
const store = useMedicoStore()
store.getCitas('ABIERTA')

const state = reactive({
  date: dayjs(new Date(props.year, props.month, 1)),
  dayNames: ['Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab', 'Dom']
})

const days = computed(() => {
  const endMonth = state.date.endOf('month')
  const firstDay = (state.date.day() + 6) % 7
  const weeks = Math.ceil((firstDay + endMonth.date()) / 7)

  return Array(weeks * 7).fill('').map((value, index) => {
    if (index >= firstDay) {
      const day = index - firstDay + 1
      if (day <= endMonth.date()) {
        return day
      }
    }
    return value
  })
})

const citas = computed(() => {
  return store.state.citas.reduce((prev, current) => {
    const citaDate = dayjs(current.fecha).format('YYYYMMDD')
    if (!prev.hasOwnProperty(citaDate)) {
      prev[citaDate] = []
    }
    prev[citaDate].push(current)
    return prev
  }, {})
})

function getMonthName (month) {
  return ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'][month]
}

function getDayCitas (day) {
  const date = dayjs(new Date(state.date.year(), state.date.month(), day)).format('YYYYMMDD')
  if (citas.value.hasOwnProperty(date)) {
    return citas.value[date]
  }
  return []
}

function cambiarMes (incremento) {
  state.date = state.date.add(incremento, 'month')
}

</script>

<template>
  <article class="message">
    <div class="message-header month-name mb-0">
      <span class="fas fa-angle-left is-left"
            @click="cambiarMes(-1)">
      </span>
      {{ getMonthName(state.date.month()) + ' - ' + state.date.year() }}
      <span class="fas fa-angle-right is-right"
            @click="cambiarMes(1, 'month')">
      </span>
    </div>
    <div class="message-body calendar p-0">
      <article class="message is-primary is-small mb-0"
               v-for="(day, index) in state.dayNames"
               :key="index">
        <p class="message-header"
           :class="{ 'not-first-day': index }">
          {{ day }}
        </p>
      </article>
      <CalendarDayComponent v-for="(day, index) in days"
                            :index="index"
                            :citas="getDayCitas(day)"
                            :day="day"
                            :key="index">
      </CalendarDayComponent>
    </div>

  </article>
</template>

<style lang="scss" scoped>

.calendar {
  display: grid;
  grid-template-columns: repeat(7, 1fr);

  .message-header {
    border: 1px solid gray;
    border-radius: 0;

    &.not-first-day {
      border-left: 0;
    }
  }

}

</style>
