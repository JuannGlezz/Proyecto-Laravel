<script setup>
import { computed, reactive } from 'vue'
import { usePacienteStore } from '@/stores/paciente'

import dayjs from 'dayjs'
dayjs.locale('es')

const store = usePacienteStore()
store.getPaciente()

const state = reactive({
  errors: {
    nombre: false,
    apellidos: false,
    fechaNacimiento: false,
    telefono: false,
    genero: false
  }
})
const fechaNacimiento = computed(() => dayjs(store.paciente.fechaNacimiento).format('YYYY-MM-DD'))

function validateForm () {
  state.errors.nombre = !store.paciente.nombre
  state.errors.apellidos = !store.paciente.apellidos
  state.errors.fechaNacimiento = !store.paciente.fechaNacimiento
  state.errors.telefono = !store.paciente.telefono

  state.errors.genero = !store.paciente.genero
}

function getErrorMsg (err) {
  if (err && err.response && err.response.data && err.response.data.message) {
    return err.response.data.message
  }
  return 'Error desconocido, por favor inténtelo de nuevo más tarde.'
}

function submitForm () {
  validateForm()
  const hasErrors = Object.keys(state.errors).reduce((result, key) => {
    return result || state.errors[key]
  }, false)
  if (!hasErrors) {
    store.paciente.fechaNacimiento = fechaNacimiento.value
    store.updatePaciente(store.paciente)
      .then(
        () => {
          alert('Datos guardados correctamente')
        },
        (err) => alert(getErrorMsg(err))
      )
  }
}

</script>

<template>
  <div class="container mx-5" v-if="store.paciente">
    <article class="">

      <nav class="panel" aria-label="Datos de acceso">
        <p class="panel-heading">Datos de acceso</p>
        <div class="columns panel-block">
          <div class="field column">
            <label class="label">DNI/NIE</label>
            <div class="control has-icons-left has-icons-right">
              <input type="text"
                     placeholder="DNI/NIE"
                     class="input"
                     v-model="store.paciente.documento"
                     disabled>
              <span class="icon is-small is-left">
              <i class="fas fa-user"></i>
            </span>
            </div>
          </div>
          <div class="field column">
            <label class="label">Contraseña</label>
            <div class="control">
              <input class="input"
                     placeholder="Contraseña"
                     type="password"
                     value="12345"
                     disabled>
            </div>
          </div>
          <div class="field"></div>
        </div>
      </nav>

      <nav class="panel" aria-label="Datos personales">
        <p class="panel-heading">Datos personales</p>

        <div class="columns panel-block">
          <div class="field column">
            <label class="label">Nombre</label>
            <div class="control">
              <input type="text"
                     placeholder="Nombre"
                     class="input"
                     :class="{ 'is-danger': state.errors.nombre }"
                     v-model="store.paciente.nombre">
            </div>
          </div>
          <div class="field column">
            <label class="label">Apellidos</label>
            <div class="control">
              <input type="text"
                     placeholder="Apellidos"
                     class="input"
                     :class="{ 'is-danger': state.errors.apellidos }"
                     v-model="store.paciente.apellidos">
            </div>
          </div>
        </div>
        <div class="columns panel-block">
          <div class="field column is-3">
            <label class="label">Fecha de nacimiento</label>
            <div class="control">
              <input type="date"
                      placeholder="Fecha de nacimiento"
                      class="input"
                      :class="{ 'is-danger': state.errors.fechaNacimiento }"
                      v-model="fechaNacimiento">
            </div>
          </div>
          <div class="field column is-3">
            <label class="label">Teléfono</label>
            <div class="control">
              <input type="tel"
                      placeholder="Teléfono"
                      class="input"
                      :class="{ 'is-danger': state.errors.telefono }"
                      v-model="store.paciente.telefono">
            </div>
          </div>
          <div class="field column">
            <label class="label">Género</label>
            <div class="control">
              <label class="radio">
                <input type="radio" value="M" v-model="store.paciente.genero">
                Masculino
              </label>
              <label class="radio">
                <input type="radio" value="F" v-model="store.paciente.genero">
                Femenino
              </label>
            </div>
            <p class="help is-danger column is-12 pt-0" v-if="state.errors.genero">Por favor, seleccione una
              opción</p>
          </div>
        </div>
      </nav>

      <div class="field is-grouped is-justify-content-center">
        <div class="control">
          <button class="button is-link" @click="submitForm()">Guardar</button>
        </div>
      </div>
    </article>
  </div>
</template>

<style lang="scss" scoped>
.columns, .column {
  margin-bottom: 0;
}

.panel-block:not(:last-child) {
  border: none;
  margin-bottom: 0;

  .column {
    margin-bottom: 0;
  }
}
</style>
