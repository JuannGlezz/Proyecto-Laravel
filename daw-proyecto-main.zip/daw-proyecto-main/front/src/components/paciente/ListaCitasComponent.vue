<script setup>
import { usePacienteStore } from '@/stores/paciente'
import { computed, reactive } from 'vue'

import dayjs from 'dayjs'
dayjs.locale('es')

const emit = defineEmits(['edit'])

const store = usePacienteStore()
store.getCitas()

const PAGE_SIZE = 3
const pages = computed(() => new Array(Math.ceil(store.citas.length / PAGE_SIZE)))

const state = reactive({
  pages,
  current: 0
})

function formatFecha (fecha) {
  return dayjs(fecha).format('dddd, DD [de] MMMM [de] YYYY [a las] HH:mm')
}

function getCitas () {
  const inicio = state.current * PAGE_SIZE
  return store.citas.slice(inicio, inicio + PAGE_SIZE)
}

function isEditable (fecha) {
  // permitimos editar la cita hasta 1 hora antes
  const fechaLimite = new Date()
  fechaLimite.setHours(fechaLimite.getHours() + 1)
  return new Date(fecha) > fechaLimite
}

function editarCita (cita) {
  store.setCita(cita)
  emit('edit')
}

</script>

<template>
  <div class="container mx-5">
    <nav class="panel" aria-label="Citas del paciente">
      <p class="panel-heading">Mis citas</p>
      <div class="panel-block mx-2 is-flex is-flex-direction-column">

        <table class="table" aria-label="Listado de citas">
          <thead>
          <tr>
            <th scope="fecha">Fecha</th>
            <th scope="medico">Medico</th>
            <th scope="acciones"></th>
          </tr>
          </thead>
          <tfoot>
          <tr>
            <th class="pt-5" colspan="4" scope="footer">* Solo se podrá editar la cita hasta 1 hora antes de la fecha agendada</th>
          </tr>
          </tfoot>
          <tbody>
          <tr v-for="cita in getCitas()" :key="cita.id">
            <td>{{ formatFecha(cita.fecha) }}</td>
            <td>{{ cita.medico.nombre + ' ' + cita.medico.apellidos }}</td>
            <td>
              <button class="button is-info is-small" v-show="isEditable(cita.fecha)">
                <span class="icon is-small" @click="editarCita(cita)">
                  <i class="fas fa-edit"></i>
                </span>
              </button>
            </td>
          </tr>
          </tbody>
        </table>

        <div class="container">
          <nav class="pagination is-centered" role="navigation" aria-label="pagination">
            <ul class="pagination-list">
              <li v-for="(page, index) in state.pages" :key="index">
                <a class="pagination-link" :class="{ 'is-current': index === state.current }" @click="state.current = index">{{ index + 1 }}</a>
              </li>
            </ul>
          </nav>
        </div>

      </div>
    </nav>

  </div>
</template>
