<script setup>
import { reactive } from 'vue'
import { usePacienteStore } from '@/stores/paciente'

import dayjs from 'dayjs'
dayjs.locale('es')

const store = usePacienteStore()
store.getMedicos()

const state = reactive({
  paso: 0,
  minDate: dayjs().format('YYYY-MM-DD'),
  idCita: null,
  idMedico: '',
  turno: null,
  title: 'Agendar nueva cita',
  fecha: '',
  hora: ''
})

if (store.cita.id) {
  state.paso = 4
  state.idCita = store.cita.id
  state.idMedico = store.cita.medico.id
  state.title = 'Editar cita'

  const fecha = dayjs(store.cita.fecha)
  state.fecha = fecha.format('YYYY-MM-DD')
  state.hora = fecha.format('HH:mm')

  const turno = state.hora < '14:00' ? 'm' : 't'
  state.turno = turno
  getHoras(turno)
  selectHora()
}

function getHoras (turno) {
  const horaInicio = turno === 't' ? 14 : 8
  const horaFin = horaInicio + 6
  state.horas = []
  for (let i = horaInicio; i < horaFin; i++) {
    const hora = ('' + i).padStart(2, '0')
    state.horas.push(`${hora}:00`, `${hora}:15`, `${hora}:30`, `${hora}:45`)
  }
  state.paso = 3
}

function selectMedico () {
  state.paso = 1
}

function selectFecha () {
  state.turno = ''
  state.hora = ''
  state.paso = 2
}

function selectTurno (turno) {
  state.hora = ''
  getHoras(turno)
  state.paso = 3
}

function selectHora () {
  state.paso = 4
}

function confirmarCita () {
  const fecha = Date.parse(state.fecha + ' ' + state.hora)
  store.saveCita({
    id: state.idCita,
    idMedico: state.idMedico,
    fecha
  }).then(() => {
    alert(state.idCita ? 'La cita ha sido actualizada correctamente' : 'La cita ha sido creada correctamente')
    resetFormCita()
  }, () => {
    alert('Se ha producido un error y la cita no ha podido guardarse, inténtelo de nuevo más tarde')
  })
}

function resetFormCita () {
  state.paso = 0
  state.idMedico = ''
  state.turno = null
  state.fecha = ''
  state.hora = ''
  state.horas = []
}

</script>

<template>
  <div class="container cita mx-5">
    <nav class="panel">
      <p class="panel-heading">{{ state.title }}</p>
      <div class="columns panel-block">
        <div class="field column">
          <label class="label">Médico</label>
          <div class="select">
            <select v-model="state.idMedico" @change="selectMedico()">
              <option disabled value="">Seleccione un médico...</option>
              <option v-for="(medico, index) in store.medicos"
                      :key="index" :value="medico.id">
                {{ medico.nombre + ' ' + medico.apellidos }}
              </option>
            </select>
          </div>
        </div>
        <div class="field column">
          <label class="label">Fecha</label>
          <input class="input" type="date"
                 v-model="state.fecha"
                 :min="state.minDate"
                 :disabled="state.paso < 1"
                 @change="selectFecha()">
        </div>
        <div class="field column">
          <label class="label">Turno</label>
          <div class="control has-icons-left has-icons-right">
            <input type="radio"
                   name="turno"
                   class="radio"
                   value="m"
                   v-model="state.turno"
                   @change="selectTurno('m')"
                   :disabled="state.paso < 2"> Mañana
            <br>
            <input type="radio"
                   name="turno"
                   class="radio"
                   value="t"
                   v-model="state.turno"
                   @change="selectTurno('t')"
                   :disabled="state.paso < 2"> Tarde
          </div>
        </div>
        <div class="field column">
          <label class="label">Hora</label>
          <div class="select">
            <select v-model="state.hora" @change="selectHora()" :disabled="state.paso < 3">
              <option disabled value="">Seleccione una hora...</option>
              <option v-for="(hora, index) in state.horas" :key="index" :value="hora">{{ hora }}</option>
            </select>
          </div>
        </div>
      </div>
      <div class="column has-text-centered">
          <button class="button is-success" @click="confirmarCita()" :disabled="state.paso < 4">Confirmar</button>
        </div>
    </nav>
  </div>

</template>

<style lang="scss" scoped>
.cita {
  min-width: 700px;
}
</style>
