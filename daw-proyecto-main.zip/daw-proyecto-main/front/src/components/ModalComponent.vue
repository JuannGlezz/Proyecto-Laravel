<script setup>
import { useMainStore } from '@/stores/main'
import CitaComponent from '@/components/medico/CitaComponent.vue'
import TermsAndConditionsComponent from '@/components/TermsAndConditionsComponent.vue'

const store = useMainStore()

function close () {
  store.setModal(null, null)
}
</script>

<template>
  <div class="modal" :class="{ 'is-active': store.showModal }">
    <div class="modal-background"></div>
    <div class="modal-content">
      <CitaComponent v-if="store.showModal === 'CITA'" @close="close" :cita="store.modalData" />
      <TermsAndConditionsComponent v-if="store.showModal === 'TERMS'" @close="close" />
    </div>
  </div>
</template>

<style scoped>

.modal-content {
  min-width: 800px;
  overflow: visible;
}

</style>
