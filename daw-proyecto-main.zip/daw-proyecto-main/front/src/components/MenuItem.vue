<script setup>
import { computed } from 'vue'
import { useMedicoStore } from '@/stores/medico'

const props = defineProps(['title'])
const emit = defineEmits(['select'])

const store = useMedicoStore()
const isSelected = computed(() => store.state.selectedItem === props.title)

function selectItem () {
  store.selectAdminMenuItem(props.title)
  emit('select', props.title)
}

</script>

<template>
  <p class="menu-label" :class="{ 'selected': isSelected }" v-html="title" @click="selectItem()"></p>
</template>

<style lang="scss" scoped>

.menu-label {
  margin: 0 auto !important;
  padding: 0.5rem 0 0.5rem 1rem;
  cursor: pointer;

  &:hover {
    text-decoration: underline;
  }
}

.selected {
  color: white;
  background-color: rgb(72, 199, 142);
  /* box-shadow: rgba(72, 199, 142, 1) 0px 8px 24px;*/
}

</style>
