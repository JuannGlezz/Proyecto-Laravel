<script setup>
import { reactive } from 'vue'
const state = reactive({
  show: false,
  title: 'Prueba',
  timer: null
})

window.addEventListener('toast', (ev) => {
  state.show = true
  state.title = ev.detail
  if (state.timer === null) {
    state.timer = setTimeout(() => {
      state.show = false
      state.timer = null
    }, 2500)
  }
})

</script>

<template>
    <div class="toast" :class="{ 'show': state.show }">
        {{ state.title }}
    </div>
</template>

<style lang="scss">
.toast {
    position: absolute;
    margin: 0 auto;
    width: auto;
    padding: 20px;
    border-radius: 10px;
    background-color: rgba($color: #FF5555, $alpha: 1);

    top: -64px;
    left: 50%;
    transform: translate(-50%, 0);
    transition: all 0.5s ease-in-out;

    &.show {
      top: 10px;
    }

}
</style>
