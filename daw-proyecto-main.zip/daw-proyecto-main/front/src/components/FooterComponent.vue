<template>
  <footer class="footer">
    <div class="has-text-white">© 2023 Centro Médico La Paz</div>
    <div class="content has-text-centered">
      <p class="rrss">
        <a href="https://www.educa2.madrid.org/web/centro.ies.lapaz.alcobendas">
          <i class="fab fa-facebook-square fa-2x"></i>
        </a>
        <a href="https://www.educa2.madrid.org/web/centro.ies.lapaz.alcobendas">
          <i class="fab fa-twitter-square fa-2x"></i>
        </a>
        <a href="https://www.educa2.madrid.org/web/centro.ies.lapaz.alcobendas">
          <i class="fab fa-instagram fa-2x"></i>
        </a>
        <a href="https://www.educa2.madrid.org/web/centro.ies.lapaz.alcobendas">
          <i class="fab fa-snapchat fa-2x"></i>
        </a>
      </p>
    </div>
    <div class="has-text-white">Developed by<a class="has-text-white" href="https://github.com/josegilmon" target="_blank">Team Medic</a></div>
  </footer>
</template>

<script></script>

<style lang="scss" scoped>
  footer {
    background-color: rgba(72, 199, 142, 1);
    padding: 3rem 1.5rem 1rem;
    display: grid;
    grid-template-columns: auto 1fr auto;

    .rrss {
      a {
        color: white;
        padding: 10px;
      }
    }
  }
</style>
