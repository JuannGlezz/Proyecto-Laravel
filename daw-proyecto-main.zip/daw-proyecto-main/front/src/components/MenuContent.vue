<script setup>
import { computed } from 'vue'
import { useMedicoStore } from '@/stores/medico'

const props = defineProps(['title'])

const store = useMedicoStore()
const isSelected = computed(() => store.state.selectedItem === props.title)

</script>

<template>
  <div v-if="isSelected">
    <slot></slot>
  </div>
</template>

<style scoped>

</style>
