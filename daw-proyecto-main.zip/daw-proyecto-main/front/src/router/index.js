import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import LoginAdminView from '../views/LoginAdminView.vue'
import LoginPacienteView from '../views/LoginPacienteView.vue'
import ServicesView from '../views/ServicesView.vue'
import AboutView from '../views/AboutView.vue'
import ContactView from '../views/ContactView.vue'
import PacienteHomeView from '../views/paciente/PacienteHomeView.vue'
import CreaPacienteView from '../views/paciente/CreaPacienteView.vue'
import NotFoundView from '../views/NotFoundView.vue'

import AdminView from '../views/admin/AdminView.vue'

import { useAuthStore } from '@/stores/auth'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/login',
      name: 'login',
      component: LoginAdminView
    },
    {
      path: '/login-paciente',
      name: 'loginPaciente',
      component: LoginPacienteView
    },
    {
      path: '/services',
      name: 'services',
      component: ServicesView
    },
    {
      path: '/about',
      name: 'about',
      component: AboutView
    },
    {
      path: '/contact',
      name: 'contact',
      component: ContactView
    },
    {
      path: '/paciente',
      name: 'view-paciente',
      component: PacienteHomeView
    },
    {
      path: '/register',
      name: 'crea-paciente',
      component: CreaPacienteView
    },
    {
      path: '/admin',
      name: 'admin',
      component: AdminView
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'not-found',
      component: NotFoundView
    }
  ]
})

router.beforeEach((to) => {
  const store = useAuthStore()
  if ((to.name === 'admin' && !store.tokenAdmin) || (to.name === 'view-paciente' && !store.tokenPaciente)) {
    router.push('/')
  }
})

export default router
